window.TELAVIP_CONFIG = {
  APP_NAME: 'TelaVip Super',
  VERSAO: '2.0.0',
  PAINEL_URL: '',
  PAINEL_SENHA: '',
  INTERVALO_VERIFICACAO: 30,
  INTERVALO_REVALIDACAO: 30,
  PALAVRAS_ESPORTE: ['esporte','sport','futebol','jogo','premiere','combate','ufc','nba','nfl','espn','sportv','fight','luta','copa','libertadores','brasileir'],
  PALAVRAS_ADULTO: ['adult','adulto','xxx','+18','18+','porn','sex']
};
