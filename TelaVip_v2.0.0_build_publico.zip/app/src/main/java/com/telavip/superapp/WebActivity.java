package com.telavip.superapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

/** Abre um link (YouTube, página de vídeo) em tela cheia, dentro do próprio app. */
public class WebActivity extends Activity {

    private WebView web;
    private FrameLayout raiz;
    private View videoCheio;
    private WebChromeClient.CustomViewCallback videoCallback;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        telaCheia();

        raiz = new FrameLayout(this);
        raiz.setBackgroundColor(0xFF000000);
        setContentView(raiz);

        web = new WebView(this);
        raiz.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }

        web.setBackgroundColor(0xFF000000);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (videoCheio != null) { callback.onCustomViewHidden(); return; }
                videoCheio = view; videoCallback = callback;
                raiz.addView(view, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                web.setVisibility(View.GONE);
                telaCheia();
            }

            @Override
            public void onHideCustomView() {
                if (videoCheio == null) return;
                raiz.removeView(videoCheio);
                videoCheio = null;
                web.setVisibility(View.VISIBLE);
                if (videoCallback != null) { videoCallback.onCustomViewHidden(); videoCallback = null; }
                telaCheia();
            }
        });

        String url = getIntent() != null ? getIntent().getStringExtra("url") : null;
        if (url == null || url.length() == 0) { finish(); return; }
        web.loadUrl(url);
    }

    public static void abrir(Activity de, String url) {
        Intent i = new Intent(de, WebActivity.class);
        i.putExtra("url", url);
        de.startActivity(i);
    }

    private void telaCheia() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public boolean onKeyDown(int codigo, KeyEvent e) {
        if (codigo == KeyEvent.KEYCODE_BACK) {
            if (videoCheio != null) { web.getWebChromeClient().onHideCustomView(); return true; }
            if (web.canGoBack()) { web.goBack(); return true; }
            finish();
            return true;
        }
        return super.onKeyDown(codigo, e);
    }

    @Override
    protected void onPause() { super.onPause(); if (web != null) web.onPause(); }

    @Override
    protected void onResume() { super.onResume(); if (web != null) web.onResume(); telaCheia(); }

    @Override
    protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
