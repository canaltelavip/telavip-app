package com.telavip.superapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.JavascriptInterface;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {

    private WebView web;
    private long ultimoVoltar = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        telaCheia();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        }
        // marca que está rodando dentro do APK (o app usa isso para saber o que liberar)
        s.setUserAgentString(s.getUserAgentString() + " TelaVipAPK/2.0.0");

        web.addJavascriptInterface(new Ponte(), "TelaVipNativo");

        CookieManager.getInstance().setAcceptCookie(true);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        }

        web.setBackgroundColor(0xFF1C1C1C);
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onConsoleMessage(ConsoleMessage cm) { return true; }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, int codigo, String desc, String url) {
                // se a versão atualizada não abrir, volta para a que veio no APK
                if (url != null && url.contains(getFilesDir().getAbsolutePath())) {
                    Atualizador.voltarParaOriginal(MainActivity.this);
                    v.loadUrl("file:///android_asset/www/index.html");
                }
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, String url) {
                // links externos (WhatsApp, YouTube) abrem fora do app
                if (url.startsWith("http") && !url.contains("android_asset")) {
                    try {
                        startActivity(new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)));
                        return true;
                    } catch (Exception e) { return false; }
                }
                return false;
            }
        });

        if (!temInternet()) {
            Toast.makeText(this, "Sem conexão com a internet", Toast.LENGTH_LONG).show();
        }
        // prepara o Chromecast (em aparelho sem serviços do Google ele simplesmente não liga)
        Transmissor.iniciar(this);

        web.loadUrl(Atualizador.enderecoInicial(this));

        // procura atualização das telas em segundo plano
        web.postDelayed(new Runnable() {
            @Override public void run() { verificarAtualizacao(false); }
        }, 3000);
    }

    /** Funções que o app (JavaScript) pode chamar no Android. */
    public class Ponte {
        @JavascriptInterface
        public void abrirWeb(final String url) {
            runOnUiThread(new Runnable() {
                @Override public void run() { WebActivity.abrir(MainActivity.this, url); }
            });
        }

        /** Chamado pelo botão "Buscar atualização" dentro do app. */
        @JavascriptInterface
        public void buscarAtualizacao() {
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Toast.makeText(MainActivity.this, "Procurando atualização...", Toast.LENGTH_SHORT).show();
                    verificarAtualizacao(true);
                }
            });
        }

        @JavascriptInterface
        public String versaoTelas() { return Atualizador.versaoEmUso(MainActivity.this); }

        /** Abre o vídeo no Exo Player, em tela separada. */
        @JavascriptInterface
        public boolean abrirExo(final String url, final String titulo) {
            if (url == null || url.trim().length() == 0) return false;
            runOnUiThread(new Runnable() {
                @Override public void run() { PlayerActivity.abrir(MainActivity.this, url, titulo); }
            });
            return true;
        }

        /** Igual ao anterior, mas levando o item para o botão de favoritar funcionar. */
        @JavascriptInterface
        public boolean abrirExoCompleto(final String url, final String titulo, final String tipo, final String id, final boolean favorito) {
            if (url == null || url.trim().length() == 0) return false;
            runOnUiThread(new Runnable() {
                @Override public void run() { PlayerActivity.abrir(MainActivity.this, url, titulo, tipo, id, favorito); }
            });
            return true;
        }

        /** Manda o vídeo para o VLC instalado no aparelho. */
        @JavascriptInterface
        public boolean abrirVlc(final String url, final String titulo) {
            if (url == null || url.trim().length() == 0) return false;
            if (!temVlc()) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "O VLC não está instalado neste aparelho.", Toast.LENGTH_LONG).show();
                    }
                });
                return false;
            }
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    try {
                        android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_VIEW);
                        i.setPackage("org.videolan.vlc");
                        i.setDataAndTypeAndNormalize(android.net.Uri.parse(url), "video/*");
                        i.putExtra("title", titulo == null ? "" : titulo);
                        i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Não consegui abrir o VLC.", Toast.LENGTH_LONG).show();
                    }
                }
            });
            return true;
        }

        /** Diz ao app se o VLC existe neste aparelho. */
        @JavascriptInterface
        public boolean temVlc() {
            try {
                getPackageManager().getPackageInfo("org.videolan.vlc", 0);
                return true;
            } catch (Exception e) { return false; }
        }

        /** Transmite o vídeo para a TV (Chromecast). */
        @JavascriptInterface
        public boolean transmitir(final String url, final String titulo, final String imagem, final boolean aoVivo) {
            if (!Transmissor.disponivel() || url == null || url.trim().length() == 0) return false;
            Transmissor.transmitir(MainActivity.this, url, titulo, imagem, aoVivo);
            return true;
        }
    }

    private void verificarAtualizacao(final boolean manual) {
        Atualizador.verificar(this, manual, new Atualizador.Aviso() {
            @Override
            public void pronto(final String versaoNova) {
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this, "Aplicativo atualizado para a versão " + versaoNova, Toast.LENGTH_LONG).show();
                        if (web != null) web.loadUrl(Atualizador.enderecoInicial(MainActivity.this));
                    }
                });
            }

            @Override
            public void falhou(final String motivo) {
                if (!manual) return;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(MainActivity.this,
                                "sem_novidade".equals(motivo) ? "Você já está na versão mais recente"
                                                              : "Não consegui atualizar agora", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private boolean temInternet() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo n = cm.getActiveNetworkInfo();
            return n != null && n.isConnected();
        } catch (Exception e) { return true; }
    }

    private void telaCheia() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean tem) {
        super.onWindowFocusChanged(tem);
        if (tem) telaCheia();
    }

    @Override
    public boolean onKeyDown(int codigo, KeyEvent e) {
        if (codigo == KeyEvent.KEYCODE_BACK) {
            // manda o "voltar" para dentro do app (fecha player, volta de tela)
            web.evaluateJavascript(
                    "(function(){try{var e=new KeyboardEvent('keydown',{key:'Escape',bubbles:true});document.dispatchEvent(e);" +
                    "return (window.App&&App.podeSair&&App.podeSair())?'sair':'ok';}catch(x){return 'sair';}})();",
                    valor -> {
                        if (valor != null && valor.contains("sair")) {
                            long agora = System.currentTimeMillis();
                            if (agora - ultimoVoltar < 2500) {
                                finish();
                            } else {
                                ultimoVoltar = agora;
                                Toast.makeText(MainActivity.this, "Aperte voltar de novo para sair", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
            return true;
        }
        return super.onKeyDown(codigo, e);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        telaCheia();
        aplicarFavoritoDoExo();
    }

    /** O coração da tela do Exo só muda de verdade aqui, onde o app guarda os favoritos. */
    private void aplicarFavoritoDoExo() {
        if (!PlayerActivity.favoritoAlternado) return;
        String tipo = PlayerActivity.favoritoTipo;
        String id = PlayerActivity.favoritoId;
        PlayerActivity.favoritoAlternado = false;
        PlayerActivity.favoritoTipo = null;
        PlayerActivity.favoritoId = null;
        if (web == null || tipo == null || id == null || tipo.length() == 0 || id.length() == 0) return;
        String js = "(function(){try{if(window.App&&App.favoritarDeFora)App.favoritarDeFora('"
                + escaparJs(tipo) + "','" + escaparJs(id) + "');}catch(e){}})();";
        try { web.evaluateJavascript(js, null); } catch (Exception e) { /* ignora */ }
    }

    private static String escaparJs(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'");
    }

    @Override
    protected void onDestroy() {
        if (web != null) { web.loadUrl("about:blank"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
