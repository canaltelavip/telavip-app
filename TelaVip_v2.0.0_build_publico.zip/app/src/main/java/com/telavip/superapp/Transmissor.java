package com.telavip.superapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.google.android.gms.common.images.WebImage;

import java.util.ArrayList;
import java.util.List;

/**
 * Manda o vídeo para a TV pelo Chromecast.
 * Tudo protegido: em TV box sem serviços do Google, simplesmente devolve "não dá"
 * e o app volta a mostrar as instruções de espelhamento.
 */
public class Transmissor {

    private static boolean pronto = false;
    private static String urlPendente, tituloPendente, imagemPendente;
    private static boolean aoVivoPendente = false;
    private static SessionManagerListener<CastSession> ouvinte;

    /** Chamado uma vez quando o app abre. Nunca deixa o app quebrar por causa disso. */
    public static void iniciar(Context ctx) {
        if (pronto) return;
        try {
            int r = GoogleApiAvailability.getInstance().isGooglePlayServicesAvailable(ctx.getApplicationContext());
            if (r != ConnectionResult.SUCCESS) return;
            CastContext.getSharedInstance(ctx.getApplicationContext());
            pronto = true;
        } catch (Throwable t) {
            pronto = false;
        }
    }

    public static boolean disponivel() {
        return pronto;
    }

    private static CastContext contexto(Context ctx) {
        try { return CastContext.getSharedInstance(ctx.getApplicationContext()); } catch (Throwable t) { return null; }
    }

    /**
     * Manda tocar na TV. Se ainda não houver TV escolhida, abre a lista de aparelhos.
     * Vem da ponte do JavaScript, que roda em outra linha de execução, por isso tudo
     * é jogado para a linha principal antes de encostar no Chromecast.
     */
    public static void transmitir(final Activity a, final String url, final String titulo, final String imagem, final boolean aoVivo) {
        if (a == null) return;
        a.runOnUiThread(new Runnable() {
            @Override public void run() { naTelaPrincipal(a, url, titulo, imagem, aoVivo); }
        });
    }

    private static void naTelaPrincipal(final Activity a, String url, String titulo, String imagem, boolean aoVivo) {
        urlPendente = url;
        tituloPendente = titulo;
        imagemPendente = imagem;
        aoVivoPendente = aoVivo;

        final CastContext cc = contexto(a);
        if (cc == null) { aviso(a, "Transmissão não disponível neste aparelho."); return; }

        CastSession sessao = null;
        try { sessao = cc.getSessionManager().getCurrentCastSession(); } catch (Throwable t) { /* ignora */ }

        if (sessao != null && sessao.isConnected()) {
            carregar(a, sessao);
            return;
        }

        ligarOuvinte(a, cc);
        escolherAparelho(a, cc);
    }

    private static void ligarOuvinte(final Activity a, CastContext cc) {
        if (ouvinte != null) return;
        ouvinte = new SessionManagerListener<CastSession>() {
            @Override public void onSessionStarted(CastSession s, String id) { carregar(a, s); }
            @Override public void onSessionResumed(CastSession s, boolean retomou) { carregar(a, s); }
            @Override public void onSessionStartFailed(CastSession s, int erro) { aviso(a, "Não consegui conectar na TV."); }
            @Override public void onSessionStarting(CastSession s) { }
            @Override public void onSessionEnding(CastSession s) { }
            @Override public void onSessionEnded(CastSession s, int erro) { }
            @Override public void onSessionResuming(CastSession s, String id) { }
            @Override public void onSessionResumeFailed(CastSession s, int erro) { }
            @Override public void onSessionSuspended(CastSession s, int motivo) { }
        };
        try {
            SessionManager sm = cc.getSessionManager();
            sm.addSessionManagerListener(ouvinte, CastSession.class);
        } catch (Throwable t) { /* ignora */ }
    }

    /** Procura TVs na rede por alguns segundos e mostra a lista. */
    private static void escolherAparelho(final Activity a, final CastContext cc) {
        final MediaRouter router;
        final MediaRouteSelector seletor;
        try {
            router = MediaRouter.getInstance(a.getApplicationContext());
            seletor = cc.getMergedSelector();
        } catch (Throwable t) { aviso(a, "Transmissão não disponível neste aparelho."); return; }
        if (seletor == null) { aviso(a, "Transmissão não disponível neste aparelho."); return; }

        final MediaRouter.Callback varredura = new MediaRouter.Callback() { };
        try {
            router.addCallback(seletor, varredura, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
        } catch (Throwable t) { /* ignora */ }

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                final List<MediaRouter.RouteInfo> achadas = new ArrayList<>();
                try {
                    for (MediaRouter.RouteInfo r : router.getRoutes()) {
                        if (r.isDefault()) continue;
                        if (r.matchesSelector(seletor)) achadas.add(r);
                    }
                } catch (Throwable t) { /* ignora */ }

                try { router.removeCallback(varredura); } catch (Throwable t) { /* ignora */ }

                if (a.isFinishing()) return;
                if (achadas.isEmpty()) { aviso(a, "Nenhuma TV encontrada na sua rede."); return; }

                String[] nomes = new String[achadas.size()];
                for (int i = 0; i < achadas.size(); i++) nomes[i] = achadas.get(i).getName();

                new AlertDialog.Builder(a)
                        .setTitle("Transmitir para")
                        .setItems(nomes, (dialogo, qual) -> {
                            try { router.selectRoute(achadas.get(qual)); } catch (Throwable t) { aviso(a, "Não consegui conectar na TV."); }
                        })
                        .setNegativeButton("Cancelar", null)
                        .show();
            }
        }, 2500);
    }

    private static void carregar(final Activity a, CastSession sessao) {
        if (urlPendente == null) return;
        RemoteMediaClient cliente;
        try { cliente = sessao.getRemoteMediaClient(); } catch (Throwable t) { cliente = null; }
        if (cliente == null) { aviso(a, "A TV conectou, mas não aceitou o vídeo."); return; }

        MediaMetadata dados = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        if (tituloPendente != null && tituloPendente.length() > 0) dados.putString(MediaMetadata.KEY_TITLE, tituloPendente);
        if (imagemPendente != null && imagemPendente.startsWith("http")) {
            try { dados.addImage(new WebImage(Uri.parse(imagemPendente))); } catch (Throwable t) { /* ignora */ }
        }

        MediaInfo info = new MediaInfo.Builder(urlPendente)
                .setStreamType(aoVivoPendente ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(tipoDoArquivo(urlPendente))
                .setMetadata(dados)
                .build();

        try {
            cliente.load(new MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build());
            aviso(a, "Enviado para a TV.");
        } catch (Throwable t) {
            aviso(a, "A TV não conseguiu abrir este vídeo.");
        }
        urlPendente = null;
    }

    private static String tipoDoArquivo(String url) {
        String u = url.toLowerCase();
        if (u.contains(".m3u8")) return "application/x-mpegURL";
        if (u.contains(".mpd")) return "application/dash+xml";
        if (u.contains(".ts")) return "video/mp2t";
        if (u.contains(".mkv")) return "video/x-matroska";
        if (u.contains(".webm")) return "video/webm";
        return "video/mp4";
    }

    private static void aviso(final Activity a, final String texto) {
        if (a == null || a.isFinishing()) return;
        a.runOnUiThread(new Runnable() {
            @Override public void run() { Toast.makeText(a, texto, Toast.LENGTH_LONG).show(); }
        });
    }
}
