package com.telavip.superapp;

import android.content.Context;
import android.util.Log;

import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Mantém os arquivos do app (telas) atualizados sem precisar reinstalar o APK.
 *
 * Como funciona:
 *  1. Ao abrir, o app usa a pasta atualizada (se existir) ou a que veio dentro do APK.
 *  2. Em segundo plano, busca o version.json no GitHub.
 *  3. Se a versão for diferente, baixa o app.zip, descompacta e troca a pasta.
 *  4. O arquivo js/config.js continua vindo do APK e não do pacote público do GitHub.
 *     Assim o bundle de atualização não precisa expor a configuração interna.
 */
public class Atualizador {

    /** Endereço do version.json no repositório público. */
    public static final String URL_VERSAO =
            "https://raw.githubusercontent.com/canaltelavip/telavip-app/main/version.json";

    private static final String TAG = "TelaVipUpdate";
    private static final String PASTA = "www";
    private static final String PASTA_TMP = "www_tmp";

    public interface Aviso {
        void pronto(String versaoNova);
        void falhou(String motivo);
    }

    /** Pasta com os arquivos atualizados, ou null se ainda não houve atualização. */
    public static File pastaAtual(Context ctx) {
        File d = new File(ctx.getFilesDir(), PASTA);
        File index = new File(d, "index.html");
        File app = new File(d, "js/app.js");
        return (index.exists() && app.exists()) ? d : null;
    }

    /** Endereço que o WebView deve carregar. */
    public static String enderecoInicial(Context ctx) {
        File d = pastaAtual(ctx);
        return d != null ? ("file://" + d.getAbsolutePath() + "/index.html")
                         : "file:///android_asset/www/index.html";
    }

    /** Apaga a pasta atualizada e volta para os arquivos de dentro do APK. */
    public static void voltarParaOriginal(Context ctx) {
        apagar(new File(ctx.getFilesDir(), PASTA));
    }

    /** Versão que está em uso agora. */
    public static String versaoEmUso(Context ctx) {
        File d = pastaAtual(ctx);
        String v = null;
        if (d != null) v = lerVersao(arquivoTexto(new File(d, "version.json")));
        if (v == null) {
            try {
                v = lerVersao(lerTudo(ctx.getAssets().open("www/version.json")));
            } catch (Exception e) { /* ignora */ }
        }
        return v == null ? "0" : v;
    }

    /** Confere e, se houver versão nova, baixa e aplica. Roda em outra thread. */
    public static void verificar(final Context ctx, final boolean avisarSemNovidade, final Aviso aviso) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String txt = baixarTexto(URL_VERSAO);
                    JSONObject j = new JSONObject(txt);
                    String nova = j.optString("versao", "");
                    String zip = j.optString("zip", "");
                    if (zip.length() == 0) {
                        zip = URL_VERSAO.replace("version.json", "app.zip");
                    }
                    String atual = versaoEmUso(ctx);
                    if (nova.length() == 0 || nova.equals(atual)) {
                        if (avisarSemNovidade && aviso != null) aviso.falhou("sem_novidade");
                        return;
                    }
                    Log.i(TAG, "Atualizando de " + atual + " para " + nova);
                    if (baixarEAplicar(ctx, zip)) {
                        if (aviso != null) aviso.pronto(nova);
                    } else {
                        if (aviso != null) aviso.falhou("falha_download");
                    }
                } catch (Exception e) {
                    Log.w(TAG, "Falha ao verificar atualização: " + e.getMessage());
                    if (aviso != null) aviso.falhou(e.getMessage());
                }
            }
        }).start();
    }

    // ---------------------------------------------------------------- interno

    private static boolean baixarEAplicar(Context ctx, String urlZip) {
        File tmp = new File(ctx.getFilesDir(), PASTA_TMP);
        apagar(tmp);
        if (!tmp.mkdirs()) return false;
        HttpURLConnection con = null;
        try {
            con = abrir(urlZip);
            if (con.getResponseCode() != 200) return false;
            InputStream in = con.getInputStream();
            ZipInputStream zip = new ZipInputStream(in);
            ZipEntry e;
            byte[] buf = new byte[16384];
            String raizTmp = tmp.getCanonicalPath();
            while ((e = zip.getNextEntry()) != null) {
                String nome = e.getName();
                if (nome.startsWith("__MACOSX") || nome.contains("..")) { zip.closeEntry(); continue; }
                File destino = new File(tmp, nome);
                if (!destino.getCanonicalPath().startsWith(raizTmp)) { zip.closeEntry(); continue; }
                if (e.isDirectory()) {
                    destino.mkdirs();
                } else {
                    File pai = destino.getParentFile();
                    if (pai != null) pai.mkdirs();
                    OutputStream out = new FileOutputStream(destino);
                    int n;
                    while ((n = zip.read(buf)) > 0) out.write(buf, 0, n);
                    out.close();
                }
                zip.closeEntry();
            }
            zip.close();

            // se o zip veio com tudo dentro de uma pasta só, sobe um nível
            File[] filhos = tmp.listFiles();
            if (filhos != null && filhos.length == 1 && filhos[0].isDirectory()
                    && !new File(tmp, "index.html").exists()) {
                File dentro = filhos[0];
                File novoTmp = new File(ctx.getFilesDir(), PASTA_TMP + "2");
                apagar(novoTmp);
                if (dentro.renameTo(novoTmp)) { apagar(tmp); novoTmp.renameTo(tmp); }
            }

            // o config fica sempre o de dentro do APK (link do painel e senha)
            copiarDosAssets(ctx, "www/js/config.js", new File(tmp, "js/config.js"));

            if (!new File(tmp, "index.html").exists() || !new File(tmp, "js/app.js").exists()) {
                apagar(tmp);
                return false;
            }

            File destinoFinal = new File(ctx.getFilesDir(), PASTA);
            apagar(destinoFinal);
            return tmp.renameTo(destinoFinal);
        } catch (Exception ex) {
            Log.w(TAG, "Erro ao aplicar atualização: " + ex.getMessage());
            apagar(tmp);
            return false;
        } finally {
            if (con != null) con.disconnect();
        }
    }

    private static void copiarDosAssets(Context ctx, String caminhoAsset, File destino) {
        try {
            File pai = destino.getParentFile();
            if (pai != null) pai.mkdirs();
            InputStream in = ctx.getAssets().open(caminhoAsset);
            OutputStream out = new FileOutputStream(destino);
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
        } catch (Exception e) {
            Log.w(TAG, "Não consegui copiar " + caminhoAsset + ": " + e.getMessage());
        }
    }

    private static HttpURLConnection abrir(String url) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("Cache-Control", "no-cache");
        c.setRequestProperty("User-Agent", "TelaVipSuper");
        return c;
    }

    private static String baixarTexto(String url) throws IOException {
        HttpURLConnection c = abrir(url + (url.contains("?") ? "&" : "?") + "t=" + System.currentTimeMillis());
        try {
            if (c.getResponseCode() != 200) throw new IOException("HTTP " + c.getResponseCode());
            return lerTudo(c.getInputStream());
        } finally {
            c.disconnect();
        }
    }

    private static String lerTudo(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        InputStreamReader r = new InputStreamReader(in, "UTF-8");
        char[] buf = new char[4096];
        int n;
        while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
        r.close();
        return sb.toString();
    }

    private static String arquivoTexto(File f) {
        try {
            if (!f.exists()) return null;
            return lerTudo(new java.io.FileInputStream(f));
        } catch (Exception e) { return null; }
    }

    private static String lerVersao(String json) {
        if (json == null) return null;
        try { return new JSONObject(json).optString("versao", null); } catch (Exception e) { return null; }
    }

    private static void apagar(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] fs = f.listFiles();
            if (fs != null) for (File x : fs) apagar(x);
        }
        f.delete();
    }
}
