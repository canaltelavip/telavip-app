package com.telavip.superapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.OptIn;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.ui.PlayerView;

/**
 * Tela separada que usa o Exo Player.
 * Serve para os arquivos que o player do WebView recusa (mkv, avi, H.265).
 * A barra de cima repete os controles do app: voltar, favoritar e transmitir.
 * Legenda e faixa de audio ficam nos botoes do proprio Exo, embaixo.
 */
@OptIn(markerClass = UnstableApi.class)
public class PlayerActivity extends Activity {

    /** Preenchido quando o usuario mexe no coracao; a MainActivity le ao voltar. */
    public static String favoritoTipo = null;
    public static String favoritoId = null;
    public static boolean favoritoAlternado = false;

    private ExoPlayer player;
    private PlayerView tela;
    private TextView aviso, txTitulo;
    private LinearLayout barra;
    private Button btFavorito;

    private String url, titulo, tipo, id;
    private boolean favorito = false;

    public static void abrir(Context ctx, String url, String titulo) {
        abrir(ctx, url, titulo, "", "", false);
    }

    public static void abrir(Context ctx, String url, String titulo, String tipo, String id, boolean favorito) {
        Intent i = new Intent(ctx, PlayerActivity.class);
        i.putExtra("url", url);
        i.putExtra("titulo", titulo == null ? "" : titulo);
        i.putExtra("tipo", tipo == null ? "" : tipo);
        i.putExtra("id", id == null ? "" : id);
        i.putExtra("favorito", favorito);
        if (!(ctx instanceof Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(i);
    }

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        telaCheia();
        setContentView(R.layout.activity_player);

        tela = findViewById(R.id.player_view);
        aviso = findViewById(R.id.aviso);
        barra = findViewById(R.id.barra_topo);
        txTitulo = findViewById(R.id.tx_titulo);
        btFavorito = findViewById(R.id.bt_favorito);

        Intent it = getIntent();
        url = it == null ? null : it.getStringExtra("url");
        titulo = it == null ? "" : String.valueOf(it.getStringExtra("titulo"));
        tipo = it == null ? "" : String.valueOf(it.getStringExtra("tipo"));
        id = it == null ? "" : String.valueOf(it.getStringExtra("id"));
        favorito = it != null && it.getBooleanExtra("favorito", false);

        if (url == null || url.trim().length() == 0) { finish(); return; }

        favoritoTipo = null; favoritoId = null; favoritoAlternado = false;

        txTitulo.setText(titulo == null ? "" : titulo);
        pintarFavorito();

        findViewById(R.id.bt_voltar).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });

        boolean temItem = tipo != null && tipo.length() > 0 && id != null && id.length() > 0;
        btFavorito.setVisibility(temItem ? View.VISIBLE : View.GONE);
        btFavorito.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                favorito = !favorito;
                favoritoAlternado = !favoritoAlternado;
                favoritoTipo = tipo;
                favoritoId = id;
                pintarFavorito();
                Toast.makeText(PlayerActivity.this, favorito ? "Adicionado aos favoritos" : "Removido dos favoritos", Toast.LENGTH_SHORT).show();
            }
        });

        findViewById(R.id.bt_transmitir).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!Transmissor.disponivel()) {
                    Toast.makeText(PlayerActivity.this, "Transmissao nao disponivel neste aparelho.", Toast.LENGTH_LONG).show();
                    return;
                }
                Toast.makeText(PlayerActivity.this, "Procurando TVs na sua rede...", Toast.LENGTH_SHORT).show();
                Transmissor.transmitir(PlayerActivity.this, url, titulo, "", false);
            }
        });

        // a barra de cima aparece e some junto com os controles do Exo
        tela.setControllerVisibilityListener(new PlayerView.ControllerVisibilityListener() {
            @Override public void onVisibilityChanged(int visibilidade) {
                barra.setVisibility(visibilidade == View.VISIBLE ? View.VISIBLE : View.GONE);
            }
        });

        DefaultHttpDataSource.Factory rede = new DefaultHttpDataSource.Factory()
                .setUserAgent("TelaVipSuper/1.8.2")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(20000)
                .setReadTimeoutMs(20000);

        DefaultLoadControl buffer = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(15000, 60000, 2000, 4000)
                .build();

        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(rede))
                .setLoadControl(buffer)
                .build();

        tela.setPlayer(player);
        tela.setKeepScreenOn(true);

        player.addListener(new Player.Listener() {
            @Override
            public void onPlayerError(PlaybackException erro) {
                mostrarAviso("Nao foi possivel reproduzir neste player.\nTente o player padrao nas configuracoes.");
            }

            @Override
            public void onIsPlayingChanged(boolean tocando) {
                if (tocando) esconderAviso();
            }
        });

        player.setMediaItem(MediaItem.fromUri(Uri.parse(url)));
        player.setPlayWhenReady(true);
        player.prepare();
    }

    private void pintarFavorito() {
        btFavorito.setText(favorito ? "\u2665" : "\u2661");
    }

    private void mostrarAviso(String texto) {
        if (aviso == null) return;
        aviso.setText(texto);
        aviso.setVisibility(View.VISIBLE);
    }

    private void esconderAviso() {
        if (aviso != null) aviso.setVisibility(View.GONE);
    }

    private void telaCheia() {
        View d = getWindow().getDecorView();
        d.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean tem) {
        super.onWindowFocusChanged(tem);
        if (tem) telaCheia();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) player.setPlayWhenReady(false);
    }

    @Override
    protected void onDestroy() {
        if (player != null) {
            try { player.release(); } catch (Exception e) { /* ignora */ }
            player = null;
        }
        super.onDestroy();
    }
}
