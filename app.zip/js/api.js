window.Api = (function () {
  var CFG = window.TELAVIP_CONFIG;

  function ehIOS() { return /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1); }
  function ehApk() { return / TelaVipAPK\//.test(navigator.userAgent) || !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); }
  function tipoAparelho() { return ehApk() ? 'APK' : 'PWA'; }

  function comTimeout(promessa, ms) {
    return new Promise(function (res, rej) {
      var t = setTimeout(function () { rej(new Error('Tempo esgotado')); }, ms);
      promessa.then(function (v) { clearTimeout(t); res(v); }, function (e) { clearTimeout(t); rej(e); });
    });
  }

  // ======================= PAINEL (planilha) =======================
  function painel(params) {
    var q = Object.keys(params).map(function (k) { return k + '=' + encodeURIComponent(params[k]); }).join('&');
    var url = CFG.PAINEL_URL + '?' + q + '&_=' + Date.now();
    return comTimeout(fetch(url, { method: 'GET', redirect: 'follow', cache: 'no-store' }), 20000)
      .then(function (r) { return r.text(); })
      .then(function (t) {
        try { return JSON.parse(t); } catch (e) { throw new Error('Resposta inválida do painel'); }
      });
  }

  function ativar() {
    var ap = Store.aparelho();
    return painel({ acao: 'ativar', codigo: ap.codigo, chave: ap.chave, senha: CFG.PAINEL_SENHA, aparelho: tipoAparelho(), versao: CFG.VERSAO });
  }

  // busca através do painel (quando o servidor da lista não aceita acesso direto do navegador)
  function viaProxy(url) {
    return painel({ acao: 'proxy', url: url, senha: CFG.PAINEL_SENHA }).then(function (r) {
      if (!r || r.ok === false) throw new Error((r && r.mensagem) || 'Falha no proxy');
      return r.conteudo;
    });
  }

  // busca texto: tenta direto, depois pelo proxy
  function buscarTexto(url, ms) {
    return comTimeout(fetch(url, { redirect: 'follow' }), ms || 30000)
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.text(); })
      .catch(function (e1) {
        return viaProxy(url).catch(function (e2) { throw new Error('Não consegui acessar o servidor da lista. ' + (e1.message || '')); });
      });
  }
  function buscarJson(url, ms) {
    return buscarTexto(url, ms).then(function (t) {
      try { return JSON.parse(t); } catch (e) { throw new Error('O servidor respondeu algo que não é uma lista válida.'); }
    });
  }

  // ======================= XTREAM =======================
  function analisarLink(link) {
    link = String(link || '').trim();
    try {
      var u = new URL(link);
      var user = u.searchParams.get('username'), pass = u.searchParams.get('password');
      if (/get\.php/i.test(u.pathname) && user && pass) {
        return { tipo: 'xtream', base: u.protocol + '//' + u.host, user: user, pass: pass, link: link };
      }
      // formato http://host/user/pass  ou  host/live/user/pass/...
      var partes = u.pathname.split('/').filter(String);
      if (partes.length === 2 && !/\./.test(partes[1])) {
        return { tipo: 'xtream', base: u.protocol + '//' + u.host, user: partes[0], pass: partes[1], link: link };
      }
    } catch (e) {}
    return { tipo: 'm3u', link: link };
  }

  function XT(conta) {
    var apiBase = conta.base + '/player_api.php?username=' + encodeURIComponent(conta.user) + '&password=' + encodeURIComponent(conta.pass);
    function acao(nome, extra) { return buscarJson(apiBase + '&action=' + nome + (extra || ''), 60000); }
    return {
      info: function () { return buscarJson(apiBase, 20000); },
      liveCats: function () { return acao('get_live_categories'); },
      liveStreams: function () { return acao('get_live_streams'); },
      vodCats: function () { return acao('get_vod_categories'); },
      vodStreams: function () { return acao('get_vod_streams'); },
      seriesCats: function () { return acao('get_series_categories'); },
      series: function () { return acao('get_series'); },
      vodInfo: function (id) { return acao('get_vod_info', '&vod_id=' + id); },
      seriesInfo: function (id) { return acao('get_series_info', '&series_id=' + id); },
      epg: function (streamId, limite) { return acao('get_short_epg', '&stream_id=' + streamId + '&limit=' + (limite || 4)); },
      urlLive: function (id, fmt) { return conta.base + '/live/' + conta.user + '/' + conta.pass + '/' + id + '.' + fmt; },
      urlVod: function (id, ext) { return conta.base + '/movie/' + conta.user + '/' + conta.pass + '/' + id + '.' + (ext || 'mp4'); },
      urlSerie: function (id, ext) { return conta.base + '/series/' + conta.user + '/' + conta.pass + '/' + id + '.' + (ext || 'mp4'); }
    };
  }

  // Carrega tudo do servidor Xtream e devolve um catálogo padronizado
  function carregarXtream(conta, aoProgresso) {
    var xt = XT(conta);
    var cat = { tipo: 'xtream', conta: conta, live: { cats: [], itens: [] }, vod: { cats: [], itens: [] }, series: { cats: [], itens: [] }, userInfo: null };
    aoProgresso('Conectando ao servidor...');
    return xt.info().then(function (info) {
      cat.userInfo = info && info.user_info ? info.user_info : null;
      if (cat.userInfo && String(cat.userInfo.auth) === '0') throw new Error('O servidor recusou o usuário e senha desta lista.');
      aoProgresso('Baixando canais...');
      return Promise.all([xt.liveCats().catch(function () { return []; }), xt.liveStreams().catch(function () { return []; })]);
    }).then(function (r) {
      cat.live.cats = normCats(r[0]);
      cat.live.itens = (r[1] || []).map(function (s) {
        return { id: String(s.stream_id), nome: s.name || '', logo: s.stream_icon || '', cat: String(s.category_id || ''), epgId: s.epg_channel_id || '', added: +s.added || 0, tipo: 'live' };
      });
      aoProgresso('Baixando filmes...');
      return Promise.all([xt.vodCats().catch(function () { return []; }), xt.vodStreams().catch(function () { return []; })]);
    }).then(function (r) {
      cat.vod.cats = normCats(r[0]);
      cat.vod.itens = (r[1] || []).map(function (s) {
        return { id: String(s.stream_id), nome: s.name || '', capa: s.stream_icon || '', cat: String(s.category_id || ''), nota: parseFloat(s.rating) || 0, added: +s.added || 0, ext: s.container_extension || 'mp4', tipo: 'vod' };
      });
      aoProgresso('Baixando séries...');
      return Promise.all([xt.seriesCats().catch(function () { return []; }), xt.series().catch(function () { return []; })]);
    }).then(function (r) {
      cat.series.cats = normCats(r[0]);
      cat.series.itens = (r[1] || []).map(function (s) {
        return { id: String(s.series_id), nome: s.name || '', capa: s.cover || '', cat: String(s.category_id || ''), nota: parseFloat(s.rating) || 0, added: +s.last_modified || 0, sinopse: s.plot || '', genero: s.genre || '', ano: (s.releaseDate || '').slice(0, 4), fundo: (s.backdrop_path && s.backdrop_path[0]) || '', tipo: 'series' };
      });
      if (!cat.live.itens.length && !cat.vod.itens.length && !cat.series.itens.length) throw new Error('O servidor não devolveu nenhum canal, filme ou série.');
      return cat;
    });
  }
  function normCats(lista) {
    return (lista || []).map(function (c) { return { id: String(c.category_id), nome: String(c.category_name || ''), nomeLimpo: limparNomeCat(c.category_name) }; });
  }
  function limparNomeCat(n) {
    return String(n || '').replace(/^\s*(canais|filmes|s[ée]ries|series|vod|live|tv)\s*[|\-:\u2013\u2014]+\s*/i, '').trim() || String(n || '');
  }

  // ======================= M3U simples =======================
  function carregarM3U(link, aoProgresso) {
    aoProgresso('Baixando a lista...');
    return buscarTexto(link, 120000).then(function (txt) {
      if (!/#EXTM3U|#EXTINF/i.test(txt)) throw new Error('O link não devolveu uma lista M3U.');
      aoProgresso('Organizando a lista...');
      var linhas = txt.split(/\r?\n/), atual = null;
      var cat = { tipo: 'm3u', link: link, live: { cats: [], itens: [] }, vod: { cats: [], itens: [] }, series: { cats: [], itens: [] } };
      var mapaCats = { live: {}, vod: {}, series: {} };
      var n = 0;
      function catId(tipo, nome) {
        nome = nome || 'Sem categoria';
        if (!mapaCats[tipo][nome]) { mapaCats[tipo][nome] = String(Object.keys(mapaCats[tipo]).length + 1); cat[tipo].cats.push({ id: mapaCats[tipo][nome], nome: nome, nomeLimpo: limparNomeCat(nome) }); }
        return mapaCats[tipo][nome];
      }
      for (var i = 0; i < linhas.length; i++) {
        var l = linhas[i].trim();
        if (!l) continue;
        if (l.indexOf('#EXTINF') === 0) {
          var attr = function (k) { var m = l.match(new RegExp(k + '="([^"]*)"', 'i')); return m ? m[1] : ''; };
          atual = { nome: (l.split(',').slice(1).join(',') || '').trim(), logo: attr('tvg-logo'), grupo: attr('group-title'), epgId: attr('tvg-id') };
        } else if (l[0] !== '#' && atual) {
          n++;
          var url = l, tipo = 'live';
          if (/\/movie\//i.test(url) || /\.(mp4|mkv|avi|mov)(\?|$)/i.test(url)) tipo = 'vod';
          if (/\/series\//i.test(url)) tipo = 'series';
          var item = { id: 'm' + n, nome: atual.nome, logo: atual.logo, capa: atual.logo, cat: catId(tipo, atual.grupo), epgId: atual.epgId, url: url, tipo: tipo, nota: 0, added: 0, ext: '' };
          if (tipo === 'series') {
            // agrupa episódios pelo nome base "Nome S01E02"
            var m = atual.nome.match(/^(.*?)\s*S(\d{1,2})\s*E(\d{1,3})/i);
            var base = m ? m[1].trim() : atual.nome;
            var serie = cat.series.itens.find(function (s) { return s.nome === base; });
            if (!serie) { serie = { id: 'S' + cat.series.itens.length, nome: base, capa: atual.logo, cat: item.cat, tipo: 'series', nota: 0, added: 0, sinopse: '', episodios: [] }; cat.series.itens.push(serie); }
            serie.episodios.push({ id: item.id, temporada: m ? +m[2] : 1, num: m ? +m[3] : serie.episodios.length + 1, titulo: atual.nome, url: url, capa: atual.logo });
          } else {
            cat[tipo].itens.push(item);
          }
          atual = null;
        }
      }
      if (!n) throw new Error('A lista veio vazia.');
      return cat;
    });
  }

  function carregarLista(link, aoProgresso) {
    var conta = analisarLink(link);
    return conta.tipo === 'xtream' ? carregarXtream(conta, aoProgresso) : carregarM3U(link, aoProgresso);
  }

  // ======================= EPG (Xtream) =======================
  function decodificarB64(s) {
    try { return decodeURIComponent(escape(atob(s))); } catch (e) { try { return atob(s); } catch (e2) { return s || ''; } }
  }
  function epgCanal(catalogo, canalId, limite) {
    if (catalogo.tipo !== 'xtream') return Promise.resolve([]);
    return XT(catalogo.conta).epg(canalId, limite).then(function (r) {
      var lista = (r && r.epg_listings) || [];
      return lista.map(function (e) {
        return { titulo: decodificarB64(e.title), descricao: decodificarB64(e.description), inicio: (+e.start_timestamp) * 1000, fim: (+e.stop_timestamp) * 1000 };
      });
    }).catch(function () { return []; });
  }

  // ======================= URLs de reprodução =======================
  function podeTocarTs() {
    try { return !!(window.mpegts && mpegts.getFeatureList().mseLivePlayback); } catch (e) { return false; }
  }
  function formatoEfetivo(cfgFormato) {
    if (cfgFormato === 'm3u8' || cfgFormato === 'ts') return cfgFormato;
    // automático: MPEG-TS é o que melhor se adapta nos canais ao vivo e vira o padrão.
    // iPhone e iPad não têm o recurso necessário para TS, então neles continua HLS.
    if (ehIOS() || !podeTocarTs()) return 'm3u8';
    return 'ts';
  }
  function urlLive(catalogo, item, fmt) {
    if (catalogo.tipo === 'xtream') return XT(catalogo.conta).urlLive(item.id, fmt);
    var u = item.url;
    if (fmt === 'm3u8') return u.replace(/\.ts(\?|$)/i, '.m3u8$1').replace(/output=(mpegts|ts)/i, 'output=m3u8');
    if (fmt === 'ts') return u.replace(/\.m3u8(\?|$)/i, '.ts$1').replace(/output=(hls|m3u8)/i, 'output=ts');
    return u;
  }
  function urlVod(catalogo, item) {
    return catalogo.tipo === 'xtream' ? XT(catalogo.conta).urlVod(item.id, item.ext) : item.url;
  }
  function urlEpisodio(catalogo, ep) {
    return catalogo.tipo === 'xtream' ? XT(catalogo.conta).urlSerie(ep.id, ep.ext) : ep.url;
  }
  // O mesmo filme costuma existir em mais de um empacotamento no servidor.
  // O navegador não abre mkv/avi, então vale tentar as outras formas antes de desistir.
  function extrasDeVideo(ext) {
    var lista = [], juntar = function (e) { e = String(e || '').toLowerCase(); if (e && lista.indexOf(e) === -1) lista.push(e); };
    juntar(ext); juntar('mp4'); juntar('m3u8'); juntar('mkv'); juntar('ts'); juntar('avi');
    return lista;
  }
  function urlsVod(catalogo, item) {
    if (catalogo.tipo !== 'xtream') return [item.url];
    var xt = XT(catalogo.conta);
    return extrasDeVideo(item.ext).map(function (e) { return xt.urlVod(item.id, e); });
  }
  function urlsEpisodio(catalogo, ep) {
    if (catalogo.tipo !== 'xtream') return [ep.url];
    var xt = XT(catalogo.conta);
    return extrasDeVideo(ep.ext).map(function (e) { return xt.urlSerie(ep.id, e); });
  }
  function vodInfo(catalogo, id) {
    if (catalogo.tipo !== 'xtream') return Promise.resolve(null);
    return XT(catalogo.conta).vodInfo(id).catch(function () { return null; });
  }
  function seriesInfo(catalogo, item) {
    if (catalogo.tipo !== 'xtream') {
      // m3u: monta a partir dos episódios agrupados
      var temps = {};
      (item.episodios || []).forEach(function (e) { (temps[e.temporada] = temps[e.temporada] || []).push(e); });
      return Promise.resolve({ info: {}, temporadas: temps });
    }
    return XT(catalogo.conta).seriesInfo(item.id).then(function (r) {
      var temps = {};
      var eps = (r && r.episodes) || {};
      Object.keys(eps).forEach(function (t) {
        temps[t] = (eps[t] || []).map(function (e) {
          var inf = e.info || {};
          return { id: String(e.id), temporada: +t, num: +e.episode_num || 0, titulo: e.title || ('Episódio ' + e.episode_num), ext: e.container_extension || 'mp4', capa: inf.movie_image || '', duracao: inf.duration || '', sinopse: inf.plot || '' };
        });
      });
      return { info: (r && r.info) || {}, temporadas: temps };
    }).catch(function () { return { info: {}, temporadas: {} }; });
  }

  return {
    ehIOS: ehIOS, ehApk: ehApk, tipoAparelho: tipoAparelho,
    ativar: ativar, painel: painel,
    analisarLink: analisarLink, carregarLista: carregarLista, limparNomeCat: limparNomeCat,
    epgCanal: epgCanal, formatoEfetivo: formatoEfetivo,
    urlLive: urlLive, urlVod: urlVod, urlEpisodio: urlEpisodio, urlsVod: urlsVod, urlsEpisodio: urlsEpisodio,
    podeTocarTs: podeTocarTs, vodInfo: vodInfo, seriesInfo: seriesInfo,
    buscarTexto: buscarTexto
  };
})();
