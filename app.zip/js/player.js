window.Player = (function () {
  var $ = function (id) { return document.getElementById(id); };
  var tela, video, ui;
  var hls = null, mp = null;                // instâncias hls.js / mpegts.js
  var atual = null;                          // o que está tocando
  var timerUI = null, timerProg = null, tentativas = 0, vigia = null, mostrouImagem = false;
  var aoFechar = null;

  function suportaHlsNativo(v) { return !!v.canPlayType && v.canPlayType('application/vnd.apple.mpegurl') !== ''; }
  function suportaMpegts() { try { return !!(window.mpegts && mpegts.getFeatureList().mseLivePlayback); } catch (e) { return false; } }

  // -------- motor de reprodução (usado pelo player grande e pela pré-visualização) --------
  function Motor(videoEl) {
    var h = null, m = null;
    function parar() {
      if (h) { try { h.destroy(); } catch (e) {} h = null; }
      if (m) { try { m.pause(); m.unload(); m.detachMediaElement(); m.destroy(); } catch (e) {} m = null; }
      try { videoEl.pause(); videoEl.removeAttribute('src'); videoEl.load(); } catch (e) {}
    }
    function tocar(url, aoErro, opcoes) {
      parar();
      opcoes = opcoes || {};
      var ehM3u8 = /\.m3u8(\?|$)/i.test(url) || /output=(hls|m3u8)/i.test(url);
      var ehTs = /\.ts(\?|$)/i.test(url) || /output=(mpegts|ts)/i.test(url);
      var bufferAlto = opcoes.buffer === 'alto';

      if (ehM3u8 && !suportaHlsNativo(videoEl) && window.Hls && Hls.isSupported()) {
        h = new Hls({
          enableWorker: true, lowLatencyMode: false,
          maxBufferLength: bufferAlto ? 60 : 30, backBufferLength: 30,
          liveSyncDurationCount: bufferAlto ? 5 : 3, manifestLoadingMaxRetry: 3, levelLoadingMaxRetry: 3, fragLoadingMaxRetry: 4
        });
        var redeErros = 0, midiaErros = 0;
        h.on(Hls.Events.ERROR, function (ev, dados) {
          if (!dados.fatal) return;
          if (dados.type === Hls.ErrorTypes.NETWORK_ERROR && dados.details !== 'manifestLoadError' && ++redeErros <= 2) { try { h.startLoad(); } catch (e) {} return; }
          if (dados.type === Hls.ErrorTypes.MEDIA_ERROR && ++midiaErros <= 2) { try { h.recoverMediaError(); } catch (e) {} return; }
          aoErro(dados.details || 'erro');
        });
        h.loadSource(url);
        h.attachMedia(videoEl);
        h.on(Hls.Events.MANIFEST_PARSED, function () { videoEl.play().catch(function () {}); });
        return 'hls';
      }
      if (ehTs && suportaMpegts()) {
        m = mpegts.createPlayer({ type: 'mpegts', isLive: true, url: url }, {
          enableWorker: true, liveBufferLatencyChasing: false, enableStashBuffer: true, stashInitialSize: bufferAlto ? 1024 * 1024 : 384 * 1024,
          autoCleanupSourceBuffer: true, autoCleanupMaxBackwardDuration: 30, autoCleanupMinBackwardDuration: 10, lazyLoad: false
        });
        m.attachMediaElement(videoEl);
        m.on(mpegts.Events.ERROR, function (tipo, det) { aoErro(det || tipo || 'erro'); });
        m.load();
        m.play().catch(function () {});
        return 'mpegts';
      }
      // nativo (Safari HLS, mp4, mkv...)
      videoEl.src = url;
      videoEl.onerror = function () { aoErro('nativo'); };
      videoEl.play().catch(function () {});
      return 'nativo';
    }
    return { tocar: tocar, parar: parar };
  }

  // -------- player grande --------
  var motor;
  function iniciar() {
    tela = $('tela-player'); video = $('video'); ui = $('player-ui');
    motor = Motor(video);

    $('pl-fechar').onclick = fechar;
    $('pl-play').onclick = alternarPlay;
    $('pl-mudo').onclick = function () { video.muted = !video.muted; atualizarVolume(); };
    $('pl-volume').oninput = function () { video.volume = $('pl-volume').value / 100; video.muted = video.volume === 0; atualizarVolume(); };
    $('pl-pular').onclick = pularIntro;
    $('pl-velocidade').onclick = function () {
      var v = [1, 1.25, 1.5, 2, 0.75], i = v.indexOf(video.playbackRate); video.playbackRate = v[(i + 1) % v.length]; $('pl-velocidade').textContent = video.playbackRate + 'x';
    };
    $('pl-ajustar').onclick = function () {
      var modos = ['ajustar', 'esticar', 'zoom'], cfg = Store.config(), i = modos.indexOf(cfg.ajusteTela);
      var novo = modos[(i + 1) % modos.length]; Store.setConfig({ ajusteTela: novo }); aplicarAjuste(); App.toast('Tela: ' + novo);
    };
    $('pl-fullscreen').onclick = function () {
      var el = document.documentElement;
      if (document.fullscreenElement) document.exitFullscreen(); else if (el.requestFullscreen) el.requestFullscreen().catch(function () {});
    };
    $('pl-formato').onclick = trocarFormato;
    $('pl-anterior').onclick = function () { navegar(-1); };
    $('pl-proximo').onclick = function () { navegar(1); };
    $('pl-legendas').onclick = alternarLegenda;
    $('pl-audio').onclick = alternarAudio;
    $('pl-menos10').onclick = function () { video.currentTime = Math.max(0, video.currentTime - 10); mostrarUI(); };
    $('pl-mais10').onclick = function () { video.currentTime += 10; mostrarUI(); };
    $('pl-fav').onclick = function () { if (atual && atual.aoFavoritar) { var on = atual.aoFavoritar(); $('pl-fav').classList.toggle('on', on); App.toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos'); } };
    $('pl-info').onclick = function () { if (atual && atual.aoInfo) atual.aoInfo(); };
    $('pl-cast').onclick = transmitir;

    $('pl-barra').oninput = function () { if (video.duration) video.currentTime = ($('pl-barra').value / 1000) * video.duration; };

    video.addEventListener('timeupdate', atualizarBarra);
    video.addEventListener('play', function () { $('pl-play').innerHTML = '&#10074;&#10074;'; });
    video.addEventListener('pause', function () { $('pl-play').innerHTML = '&#9654;'; });
    video.addEventListener('waiting', function () { msg('Carregando...'); });
    video.addEventListener('playing', function () {
      msg(''); tentativas = 0; mostrouImagem = true;
      if (atual && atual.tipo === 'live' && atual.aoTocou) atual.aoTocou(atual.formatoForcado || Api.formatoEfetivo(Store.config().formato));
    });
    video.addEventListener('ended', function () {
      if (atual && atual.tipo === 'ep') { Store.marcarVisto(atual.id); if (atual.lista && atual.indice < atual.lista.length - 1) { App.toast('Próximo episódio...'); setTimeout(function () { navegar(1); }, 1200); return; } }
      if (atual && atual.tipo === 'vod') Store.limparProgresso('vod:' + atual.id);
    });

    tela.addEventListener('mousemove', mostrarUI);
    tela.addEventListener('click', function (e) { if (e.target === video) { mostrarUI(); } });
    tela.addEventListener('touchstart', mostrarUI, { passive: true });
    tela.addEventListener('dblclick', function (e) { if (e.target === video) $('pl-fullscreen').click(); });
  }

  function msg(html) { $('pl-msg').innerHTML = html || ''; }
  function atualizarVolume() {
    $('pl-mudo').textContent = (video.muted || video.volume === 0) ? '\uD83D\uDD07' : '\uD83D\uDD0A';
    if (!video.muted) $('pl-volume').value = Math.round(video.volume * 100);
  }
  function montarQualidade(dados) {
    var q = $('pl-qual'); q.innerHTML = '';
    if (!dados.variantes || dados.variantes.length < 2 || !dados.aoQualidadeEscolher) return;
    dados.variantes.forEach(function (v) {
      var b = document.createElement('button'); b.textContent = v.rotulo; b.setAttribute('data-focusable', ''); b.className = v.id === dados.id ? 'ativo' : '';
      b.onclick = function () { if (v.id !== dados.id) dados.aoQualidadeEscolher(v.id); };
      q.appendChild(b);
    });
  }
  function montarEpg(agora, prox) {
    var e = $('pl-epg'), html = '';
    if (agora) html += '<div class="epg-agora"><span class="tag">AO VIVO</span><span class="hora">' + agora.horas + '</span><span class="prog">' + agora.titulo + '</span></div>';
    if (prox) html += '<div class="epg-prox"><span class="tag">A SEGUIR</span><span class="hora">' + prox.horas + '</span><span class="prog">' + prox.titulo + '</span></div>';
    e.innerHTML = html;
  }

  function aplicarAjuste() {
    var cfg = Store.config();
    video.className = cfg.ajusteTela === 'esticar' ? 'esticar' : (cfg.ajusteTela === 'zoom' ? 'zoom' : '');
  }

  function mostrarUI() {
    ui.classList.remove('escondido');
    clearTimeout(timerUI);
    timerUI = setTimeout(function () { if (!video.paused && !$('pl-lista').classList.contains('oculta') === false) ui.classList.add('escondido'); }, 4000);
  }

  function fmtTempo(s) {
    if (!isFinite(s) || s < 0) s = 0;
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = Math.floor(s % 60);
    return (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(x).padStart(2, '0');
  }
  function atualizarBarra() {
    if (!atual || atual.tipo === 'live' || !video.duration) return;
    $('pl-tempo').textContent = fmtTempo(video.currentTime);
    $('pl-duracao').textContent = fmtTempo(video.duration);
    $('pl-barra').value = Math.round((video.currentTime / video.duration) * 1000);
  }

  function alternarPlay() { if (video.paused) video.play().catch(function () {}); else video.pause(); }

  function alternarLegenda() {
    var tr = video.textTracks; if (!tr || !tr.length) { App.toast('Este vídeo não tem legendas embutidas'); return; }
    var ativa = -1; for (var i = 0; i < tr.length; i++) if (tr[i].mode === 'showing') ativa = i;
    for (var j = 0; j < tr.length; j++) tr[j].mode = 'disabled';
    var prox = ativa + 1; if (prox < tr.length) { tr[prox].mode = 'showing'; App.toast('Legenda: ' + (tr[prox].label || tr[prox].language || (prox + 1))); } else App.toast('Legendas desligadas');
  }
  function alternarAudio() {
    if (hls && hls.audioTracks && hls.audioTracks.length > 1) { hls.audioTrack = (hls.audioTrack + 1) % hls.audioTracks.length; App.toast('Áudio: ' + (hls.audioTracks[hls.audioTrack].name || hls.audioTrack + 1)); return; }
    var at = video.audioTracks; if (at && at.length > 1) { var i = -1; for (var k = 0; k < at.length; k++) if (at[k].enabled) i = k; var n = (i + 1) % at.length; for (var z = 0; z < at.length; z++) at[z].enabled = (z === n); App.toast('Áudio: ' + (at[n].label || at[n].language || n + 1)); return; }
    App.toast('Este vídeo tem só uma faixa de áudio');
  }

  // -------- abrir conteúdo --------
  // dados: { tipo:'live'|'vod'|'ep', id, titulo, sub, url | urlPorFormato(fmt), lista:[...], indice, retomar }
  function abrir(dados, aoFecharCb) {
    atual = dados; aoFechar = aoFecharCb || null; tentativas = 0;
    tela.classList.remove('oculta');
    $('pl-titulo').textContent = dados.titulo || '';
    $('pl-sub').textContent = dados.sub || '';
    var web = dados.tipo === 'web';
    var live = dados.tipo === 'live' || web;
    $('video-web').classList.toggle('oculta', !web);
    video.classList.toggle('oculta', web);
    document.querySelector('.player-base').classList.toggle('oculta', web);
    $('pl-barra-wrap').classList.toggle('oculta', live);
    $('pl-formato').classList.toggle('oculta', !live);
    $('pl-lista').classList.add('oculta');
    $('pl-controles-vod').classList.toggle('oculta', live);
    $('pl-dica').classList.toggle('oculta', !live);
    $('pl-formato').classList.toggle('oculta', !live);
    $('pl-pular').classList.toggle('oculta', dados.tipo !== 'ep');
    $('pl-nome').textContent = live ? (dados.titulo || '') : '';
    $('pl-logo').classList.toggle('oculta', !(live && dados.logo)); if (live && dados.logo) $('pl-logo').src = dados.logo;
    $('pl-titulo').textContent = live ? '' : (dados.titulo || '');
    montarQualidade(dados); montarEpg(null, null);
    atualizarVolume();
    var fav = !!(dados.ehFavorito && dados.ehFavorito());
    $('pl-fav').innerHTML = '<svg class="ico-cor" viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-9.3-9A5.2 5.2 0 0 1 12 6.5 5.2 5.2 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z"/></svg>'; $('pl-fav').classList.toggle('on', fav);
    $('pl-fav').classList.toggle('oculta', !dados.aoFavoritar);
    video.playbackRate = 1; $('pl-velocidade').textContent = '1x';
    aplicarAjuste();
    mostrarUI();
    if (web) {
      clearInterval(vigia);
      $('video-web').src = dados.url;
      msg('');
      if (dados.urlOriginal) {
        setTimeout(function () {
          if (!atual || atual.tipo !== 'web') return;
          msg('<span style="color:#a39e93;font-size:.9em">Se o vídeo não abrir aqui:</span><br><button class="btn btn-dourado" id="pl-fora" data-focusable>Abrir fora do app</button>');
          var b = $('pl-fora'); if (b) b.onclick = function () { window.open(dados.urlOriginal, '_blank'); };
        }, 5000);
      }
      return;
    }
    carregar();
  }

  function urlAtual() {
    if (atual.urlPorFormato) {
      var cfg = Store.config();
      var fmt = atual.formatoForcado || Api.formatoEfetivo(cfg.formato);
      $('pl-formato').textContent = fmt === 'ts' ? 'TS' : 'HLS';
      return atual.urlPorFormato(fmt);
    }
    return atual.url;
  }

  // vigia: se o vídeo não começar em 12s, ou ficar parado 15s no meio, trata como erro
  function ligarVigia() {
    clearInterval(vigia);
    var ultimoTempo = -1, ultimoAvanco = Date.now(), comecou = false, inicio = Date.now();
    vigia = setInterval(function () {
      if (!atual) { clearInterval(vigia); return; }
      if (video.paused && comecou) { ultimoAvanco = Date.now(); return; }
      var t = video.currentTime;
      if (t > 0 && t !== ultimoTempo) { ultimoTempo = t; ultimoAvanco = Date.now(); comecou = true; return; }
      var parado = Date.now() - ultimoAvanco;
      if ((!comecou && Date.now() - inicio > 8000) || (comecou && parado > 15000)) {
        var motivo = comecou ? 'travou' : 'sem imagem';
        ultimoAvanco = Date.now(); inicio = Date.now(); comecou = false;
        if (tentativas < 1) tentativas = 1;   // tela preta: pula direto para a troca de formato
        aoErro(motivo);
      }
    }, 2000);
  }
  function tocarAgora() {
    ligarVigia();
    motor.tocar(urlAtual(), aoErro, { buffer: Store.config().buffer });
  }

  function carregar() {
    msg('Carregando...');
    mostrouImagem = false;
    tocarAgora();
    // retomar de onde parou
    if (atual.tipo !== 'live') {
      var chave = (atual.tipo === 'vod' ? 'vod:' : 'ep:') + atual.id;
      var p = Store.lerProgresso(chave);
      if (p && p.pos > 30 && p.dur && p.pos < p.dur * 0.95) {
        var pos = p.pos;
        var umaVez = function () { video.removeEventListener('loadedmetadata', umaVez); try { video.currentTime = pos; } catch (e) {} App.toast('Continuando de ' + fmtTempo(pos)); };
        video.addEventListener('loadedmetadata', umaVez);
      }
      clearInterval(timerProg);
      timerProg = setInterval(function () {
        if (!atual || video.paused || !video.duration) return;
        Store.salvarProgresso(chave, { pos: video.currentTime, dur: video.duration, nome: atual.titulo, capa: atual.capa || '', sub: atual.sub || '', tipo: atual.tipo, ref: atual.ref || null });
      }, 5000);
    } else {
      clearInterval(timerProg);
      Store.registrarCanal(atual.id);
    }
  }

  function aoErro(detalhe) {
    if (!atual) return;
    tentativas++;
    // nunca mostrou imagem neste formato: não insiste, vai direto para o outro formato
    if (tentativas === 1 && !mostrouImagem && atual.tipo === 'live' && atual.urlPorFormato && !atual.trocouSozinho) tentativas = 2;
    if (tentativas === 1) {
      msg('Sinal caiu, tentando de novo...');
      setTimeout(function () { if (atual) tocarAgora(); }, 1200);
      return;
    }
    // canal ao vivo: antes de desistir, tenta o outro formato sozinho
    if (atual.tipo === 'live' && atual.urlPorFormato && !atual.trocouSozinho) {
      atual.trocouSozinho = true; tentativas = 1; mostrouImagem = false;
      var agora = atual.formatoForcado || Api.formatoEfetivo(Store.config().formato);
      atual.formatoForcado = agora === 'ts' ? 'm3u8' : 'ts';
      msg('Tentando no formato ' + (atual.formatoForcado === 'ts' ? 'MPEG-TS' : 'HLS') + '...');
      setTimeout(function () { if (atual) tocarAgora(); }, 600);
      return;
    }
    clearInterval(vigia);
    var html = '<strong>Não foi possível reproduzir</strong><br><span style="color:#a39e93;font-size:.9em">O canal pode estar fora do ar ou o formato não é compatível com este aparelho.</span><br>';
    html += '<button class="btn" id="pl-retry" data-focusable>Tentar de novo</button>';
    if (atual && atual.tipo === 'live') html += '<button class="btn btn-dourado" id="pl-troca" data-focusable>Trocar formato</button>';
    html += '<button class="btn" id="pl-sair" data-focusable>Voltar</button>';
    msg(html);
    $('pl-retry').onclick = function () { tentativas = 0; carregar(); };
    var t = $('pl-troca'); if (t) t.onclick = trocarFormato;
    $('pl-sair').onclick = fechar;
    ui.classList.remove('escondido');
  }

  function transmitir() {
    try {
      if (video.remote && video.remote.prompt) {
        video.remote.prompt().catch(function (e) { App.toast('Nenhum aparelho encontrado para transmitir'); });
        return;
      }
      if (video.webkitShowPlaybackTargetPicker) { video.webkitShowPlaybackTargetPicker(); return; }
    } catch (e) {}
    App.dialogoTransmitir();
  }

  function trocarFormato() {
    if (!atual || atual.tipo !== 'live') return;
    var cfg = Store.config();
    var agora = atual.formatoForcado || Api.formatoEfetivo(cfg.formato);
    atual.formatoForcado = agora === 'ts' ? 'm3u8' : 'ts';
    tentativas = 0; atual.trocouSozinho = true;
    App.toast('Formato: ' + (atual.formatoForcado === 'ts' ? 'MPEG-TS' : 'HLS (m3u8)'));
    carregar();
  }

  function navegar(dir) {
    if (!atual || !atual.lista || !atual.lista.length) return;
    var i = atual.indice + dir;
    if (i < 0) i = atual.lista.length - 1; if (i >= atual.lista.length) i = 0;
    var prox = atual.lista[i];
    if (atual.aoNavegar) atual.aoNavegar(prox, i);
  }

  function alternarLista(html) {
    var l = $('pl-lista');
    if (html) { l.innerHTML = html; l.classList.remove('oculta'); ui.classList.remove('escondido'); }
    else l.classList.add('oculta');
  }

  function fechar() {
    if (!atual) return;
    if (atual.tipo !== 'live' && video.duration && video.currentTime > 30) {
      Store.salvarProgresso((atual.tipo === 'vod' ? 'vod:' : 'ep:') + atual.id, { pos: video.currentTime, dur: video.duration, nome: atual.titulo, capa: atual.capa || '', sub: atual.sub || '', tipo: atual.tipo, ref: atual.ref || null });
    }
    clearInterval(timerProg); clearInterval(vigia);
    try { $('video-web').src = 'about:blank'; } catch (e) {}
    $('video-web').classList.add('oculta'); video.classList.remove('oculta');
    document.querySelector('.player-base').classList.remove('oculta');
    motor.parar();
    msg('');
    tela.classList.add('oculta');
    if (document.fullscreenElement) { try { document.exitFullscreen(); } catch (e) {} }
    var cb = aoFechar; atual = null; aoFechar = null;
    if (cb) cb();
  }

  function teclado(e) {
    if (tela.classList.contains('oculta')) return false;
    var k = e.key;
    if (k === 'Escape' || k === 'Backspace' || k === 'GoBack' || k === 'BrowserBack') { e.preventDefault(); if (!$('pl-lista').classList.contains('oculta')) alternarLista(null); else fechar(); return true; }
    if (k === ' ' || k === 'MediaPlayPause') { e.preventDefault(); alternarPlay(); return true; }
    if (atual && atual.tipo === 'live') {
      if (k === 'ArrowUp' && ui.classList.contains('escondido')) { e.preventDefault(); navegar(-1); return true; }
      if (k === 'ArrowDown' && ui.classList.contains('escondido')) { e.preventDefault(); navegar(1); return true; }
      if (k === 'Enter' && ui.classList.contains('escondido')) { e.preventDefault(); if (atual.aoListaRapida) atual.aoListaRapida(); return true; }
    } else {
      if (k === 'ArrowRight' && ui.classList.contains('escondido')) { e.preventDefault(); video.currentTime += 10; mostrarUI(); return true; }
      if (k === 'ArrowLeft' && ui.classList.contains('escondido')) { e.preventDefault(); video.currentTime -= 10; mostrarUI(); return true; }
    }
    mostrarUI();
    return false;
  }

  function pularIntro() { var cfg = Store.config(); if (cfg.pularIntro > 0) { video.currentTime += cfg.pularIntro; App.toast('Pulou ' + cfg.pularIntro + 's'); } }
  function estaAberto() { return !tela.classList.contains('oculta'); }

  return { iniciar: iniciar, abrir: abrir, fechar: fechar, teclado: teclado, Motor: Motor, alternarLista: alternarLista, pularIntro: pularIntro, estaAberto: estaAberto, atual: function () { return atual; }, montarEpg: montarEpg };
})();
