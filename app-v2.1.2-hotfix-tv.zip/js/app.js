window.TELAVIP_BUILD = '2.1.2';
window.App = (function () {
  var CFG = window.TELAVIP_CONFIG;
  var $ = function (id) { return document.getElementById(id); };
  var E = { lib: null, cat: null, rota: 'inicio', params: null, pilha: [], adultoLiberado: false, selecao: {}, busca: {}, ordem: {}, timerAtiv: null, preview: null };

  var ICO_CORACAO = '<svg class="ico-cor" viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-9.3-9A5.2 5.2 0 0 1 12 6.5 5.2 5.2 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z"/></svg>';
  function coracao(on) { return '<svg class="ico-cor' + (on ? ' on' : '') + '" viewBox="0 0 24 24"><path d="M12 21s-7.5-4.7-9.3-9A5.2 5.2 0 0 1 12 6.5 5.2 5.2 0 0 1 21.3 12c-1.8 4.3-9.3 9-9.3 9z"/></svg>'; }

  function h(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(t, ms) { var el = $('toast'); el.textContent = t; el.classList.remove('oculta'); clearTimeout(toast.t); toast.t = setTimeout(function () { el.classList.add('oculta'); }, ms || 2500); }

  // ============ diálogos ============
  function dialogo(html, aoMontar) {
    $('dialogo-caixa').innerHTML = html; $('dialogo').classList.remove('oculta');
    if (aoMontar) aoMontar($('dialogo-caixa'));
    var f = $('dialogo-caixa').querySelector('input, [data-focusable]'); if (f) f.focus();
  }
  function fecharDialogo() { $('dialogo').classList.add('oculta'); $('dialogo-caixa').innerHTML = ''; }
  function confirmar(titulo, texto, okTxt) {
    return new Promise(function (res) {
      dialogo('<h3>' + h(titulo) + '</h3><p>' + h(texto) + '</p><div class="dialogo-botoes"><button class="btn" id="dg-nao" data-focusable>Cancelar</button><button class="btn btn-vermelho" id="dg-sim" data-focusable>' + h(okTxt || 'Confirmar') + '</button></div>', function () {
        $('dg-nao').onclick = function () { fecharDialogo(); res(false); };
        $('dg-sim').onclick = function () { fecharDialogo(); res(true); };
      });
    });
  }
  function fmtRetomada(segundos) {
    var s = Math.max(0, Math.floor(Number(segundos) || 0));
    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60;
    return h > 0 ? (h + ':' + String(m).padStart(2, '0') + ':' + String(ss).padStart(2, '0')) : (String(m).padStart(2, '0') + ':' + String(ss).padStart(2, '0'));
  }
  function escolherRetomada(p) {
    return new Promise(function (res) {
      var ponto = fmtRetomada(p && p.pos);
      dialogo('<h3>Continuar assistindo?</h3><p>Você parou em <b>' + h(ponto) + '</b>.</p><div class="dialogo-botoes"><button class="btn" id="dg-inicio" data-focusable>Do início</button><button class="btn btn-dourado" id="dg-continuar" data-focusable>Continuar</button></div>', function () {
        $('dg-inicio').onclick = function () { fecharDialogo(); res(false); };
        $('dg-continuar').onclick = function () { fecharDialogo(); res(true); };
      });
    });
  }

  function pedirPin(titulo, texto) {
    return new Promise(function (res) {
      dialogo('<h3>' + h(titulo) + '</h3><p>' + h(texto) + '</p><input type="password" inputmode="numeric" maxlength="6" id="dg-pin" placeholder="PIN"><div class="dialogo-botoes"><button class="btn" id="dg-nao" data-focusable>Cancelar</button><button class="btn btn-dourado" id="dg-sim" data-focusable>OK</button></div>', function () {
        $('dg-nao').onclick = function () { fecharDialogo(); res(null); };
        $('dg-sim').onclick = function () { var v = $('dg-pin').value; fecharDialogo(); res(v); };
        $('dg-pin').onkeydown = function (e) { if (e.key === 'Enter') $('dg-sim').click(); };
      });
    });
  }

  // ============ ATIVAÇÃO ============
  function iniciar() {
    Player.iniciar();
    lerVersaoTelas();
    var ap = Store.aparelho();
    $('ativ-codigo').textContent = ap.codigo; $('ativ-chave').textContent = ap.chave;
    $('ativ-nome').textContent = CFG.APP_NAME; $('topo-nome').textContent = CFG.APP_NAME;
    $('ativ-versao').innerHTML = 'Versão <span data-versao>' + h(VERSAO_TELAS) + '</span> · ' + h(Api.tipoAparelho());
    $('ativ-copiar').onclick = function () { copiar('Código: ' + ap.codigo + '\nChave: ' + ap.chave); };
    $('ativ-verificar').onclick = function () { verificarAtivacao(true); };
    $('ativ-whats').onclick = function () {
      var w = (E.lib && E.lib.whatsapp) || '';
      if (!w) { toast('Suporte ainda não configurado'); return; }
      window.open(w + '?text=' + encodeURIComponent('Olá! Quero ativar o ' + CFG.APP_NAME + '.\nCódigo: ' + ap.codigo + '\nChave: ' + ap.chave), '_blank');
    };
    $('carregando-tentar').onclick = function () { carregarCatalogo(); };
    $('btn-sair').onclick = sair;
    $('btn-atualizar').onclick = function () { toast('Atualizando lista...'); revalidar(true).then(function () { mostrarTela('carregando'); carregarCatalogo(); }); };
    $('btn-transmitir').onclick = dialogoTransmitir;
    $('btn-instalar').onclick = instalar;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); E.installPrompt = e; });
    if (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone || Api.ehApk()) $('btn-instalar').classList.add('oculta');
    // Revalida a autorização regularmente enquanto o aparelho estiver liberado.
    // Revalida periodicamente; o servidor continua sendo a fonte da verdade.
    var intervaloRevalidacao = Math.max(15, Number(CFG.INTERVALO_REVALIDACAO || CFG.INTERVALO_VERIFICACAO || 30));
    setInterval(function () { if (E.cat || (E.lib && E.lib.ok)) revalidar(false); }, intervaloRevalidacao * 1000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden && (E.cat || (E.lib && E.lib.ok))) revalidar(true); });
    window.addEventListener('focus', function () { if (E.cat || (E.lib && E.lib.ok)) revalidar(false); });
    verificarAtualizacao();
    document.querySelectorAll('[data-rota]').forEach(function (b) { b.addEventListener('click', function () { ir(b.getAttribute('data-rota')); }); });
    var maisBtn = document.querySelector('.nav-mobile [data-rota="config"]');
    if (maisBtn) maisBtn.addEventListener('click', function (e) { e.stopPropagation(); menuMais(); }, true);
    document.addEventListener('keydown', teclado);
    aplicarModoDispositivo();
    window.addEventListener('resize', aplicarModoDispositivo);

    // Nunca confia em uma liberação antiga para entrar. O servidor é a fonte da verdade.
    // O cache local pode guardar apenas dados auxiliares (ex.: WhatsApp), mas o acesso
    // só é aberto depois de uma resposta ATUAL do painel nesta inicialização.
    var lib = Store.liberacao();
    if (lib && lib.whatsapp) E.lib = { ok: false, whatsapp: lib.whatsapp };
    mostrarTela('ativacao');
    verificarAtivacao(false);
  }

  function copiar(txt) {
    if (navigator.clipboard) navigator.clipboard.writeText(txt).then(function () { toast('Copiado'); }, function () { toast('Não consegui copiar'); });
    else toast('Copie manualmente: ' + txt);
  }

  function mostrarTela(nome) {
    ['ativacao', 'carregando', 'app'].forEach(function (t) { $('tela-' + t).classList.toggle('oculta', t !== nome); });
  }

  function limparAcessoLocal(mensagem) {
    clearTimeout(E.timerAtiv);
    Store.setLiberacao(null);
    Store.setConfig({ listaAtiva: 0 });
    E.lib = null; E.cat = null; E.selecao = {}; E.busca = {};
    try { if (Player.estaAberto()) Player.fechar(); } catch (e) {}
    mostrarTela('ativacao');
    var st = $('ativ-status');
    if (st) { st.className = 'ativ-status erro'; st.textContent = mensagem || 'Acesso não liberado. Fale com o suporte.'; }
  }

  function mostrarSemLista(mensagem) {
    E.cat = null; E.selecao = {}; E.busca = {};
    try { if (Player.estaAberto()) Player.fechar(); } catch (e) {}
    mostrarTela('carregando');
    var msgEl = $('carregando-msg');
    if (msgEl) msgEl.textContent = mensagem || 'Nenhuma lista cadastrada para este aparelho. Fale com o suporte.';
    if ($('carregando-tentar')) $('carregando-tentar').classList.add('oculta');
  }

  function listaDaLiberacao(lib) {
    var listas = (lib && lib.listas) || [];
    if (!listas.length) return null;
    var cfg = Store.config();
    var i = Math.min(Math.max(0, cfg.listaAtiva || 0), listas.length - 1);
    return listas[i] || null;
  }

  function verificarAtivacao(manual, silencioso) {
    clearTimeout(E.timerAtiv);
    var st = $('ativ-status');
    var tinhaAcesso = !!(E.cat || (E.lib && E.lib.ok) || (Store.liberacao() && Store.liberacao().ok));
    var listaAnterior = listaDaLiberacao(E.lib || Store.liberacao());
    if (!silencioso) { st.className = 'ativ-status'; st.textContent = 'Verificando liberação...'; }

    return Api.ativar().then(function (r) {
      if (r && r.ok) {
        r.listas = Array.isArray(r.listas) ? r.listas : [];
        var listaNova = listaDaLiberacao(r);
        var mudouListaAtiva = String((listaAnterior && listaAnterior.link) || '') !== String((listaNova && listaNova.link) || '');
        var mudouListas = !E.lib || JSON.stringify((E.lib && E.lib.listas) || []) !== JSON.stringify(r.listas);

        E.lib = r;
        Store.setLiberacao(r);
        mostrarMensagensNovas(r);
        if (r.config && r.config.nome_app) { $('ativ-nome').textContent = r.config.nome_app; document.title = r.config.nome_app; }

        // Autorizado, mas sem nenhuma lista: não deixa catálogo antigo continuar aberto.
        if (!r.listas.length) {
          mostrarSemLista('Nenhuma lista cadastrada para este aparelho. Fale com o suporte.');
          return r;
        }

        if (!silencioso) {
          st.className = 'ativ-status ok';
          st.textContent = 'Liberado! Entrando...';
          setTimeout(function () { mostrarTela('carregando'); carregarCatalogo(); }, 350);
        } else if (mudouListaAtiva && E.cat) {
          // Se a lista em uso foi removida/trocada, descarta o catálogo antigo e carrega o atual.
          toast('Lista atualizada no painel');
          E.cat = null;
          mostrarTela('carregando');
          carregarCatalogo();
        } else if (mudouListas && E.cat) {
          toast('Listas atualizadas no painel');
        }

        if (E.cat) { aplicarExtras(); if (E.rota === 'canais') ir('canais', null, true); }
        return r;
      }

      // Qualquer resposta válida do servidor com ok=false revoga um acesso que já estava ativo.
      // Antes só alguns status eram tratados; ao excluir o cliente o app podia cair em outro
      // status e continuar usando a liberação salva no aparelho.
      var mensagem = (r && r.mensagem) || 'Aparelho ainda não liberado.';
      if (tinhaAcesso || silencioso) {
        limparAcessoLocal(mensagem);
      } else {
        E.lib = { ok: false, whatsapp: (r && r.whatsapp) || '', status: r && r.status, mensagem: mensagem };
        st.className = 'ativ-status erro';
        st.textContent = mensagem;
      }
      E.timerAtiv = setTimeout(function () { verificarAtivacao(false); }, CFG.INTERVALO_VERIFICACAO * 1000);
      return r;
    }).catch(function (e) {
      // Sem resposta do painel não concede uma liberação nova. Se o app já estava aberto,
      // mantém a sessão até a próxima tentativa para não derrubar por uma falha momentânea.
      if (!silencioso) {
        st.className = 'ativ-status erro';
        st.textContent = 'Sem conexão com o painel. Verifique a internet. (' + (e.message || '') + ')';
        E.timerAtiv = setTimeout(function () { verificarAtivacao(false); }, CFG.INTERVALO_VERIFICACAO * 1000);
      }
      return null;
    });
  }

  // mostra em janela as mensagens (individual e geral) quando forem novas
  function mostrarMensagensNovas(r) {
    var vistas = Store.mensagensVistas(), fila = [];
    if (r.mensagem_cliente && vistas.individual !== r.mensagem_cliente) fila.push({ tipo: 'individual', titulo: 'Mensagem do suporte', texto: r.mensagem_cliente });
    var geral = r.config && r.config.mensagem_aviso;
    if (geral && vistas.geral !== geral) fila.push({ tipo: 'geral', titulo: 'Aviso', texto: geral });
    var hoje = new Date().toDateString();
    if (r.aviso_vencimento_texto && vistas.vencimento !== hoje + '|' + r.aviso_vencimento_texto) fila.push({ tipo: 'vencimento', titulo: 'Vencimento', texto: r.aviso_vencimento_texto, marca: hoje + '|' + r.aviso_vencimento_texto });
    if (!fila.length || !$('dialogo').classList.contains('oculta') || Player.estaAberto()) return;
    var m = fila[0];
    dialogo('<h3>' + h(m.titulo) + '</h3><p style="white-space:pre-line;color:var(--texto)">' + h(m.texto) + '</p><div class="dialogo-botoes"><button class="btn btn-dourado" id="dg-ok" data-focusable>OK</button></div>', function () {
      $('dg-ok').onclick = function () {
        vistas[m.tipo] = m.marca || m.texto; Store.setMensagensVistas(vistas); fecharDialogo();
        if (fila.length > 1) setTimeout(function () { mostrarMensagensNovas(r); }, 300);
        else if (E.rota === 'inicio' && E.cat) ir('inicio', null, true);
      };
    });
  }

  // reconfere o painel (bloqueio, validade, listas). forçar=true ignora o limite de 1 por minuto
  function revalidar(forcar) {
    var agora = Date.now();
    if (!forcar && E.ultimaVerif && agora - E.ultimaVerif < 20000) return Promise.resolve(E.lib);
    E.ultimaVerif = agora;
    return verificarAtivacao(false, true);
  }

  // ---------- instalação / transmissão / atualização ----------
  function instalar() {
    if (E.installPrompt) { E.installPrompt.prompt(); E.installPrompt.userChoice.then(function (r) { if (r.outcome === 'accepted') { toast('Instalado!'); $('btn-instalar').classList.add('oculta'); } E.installPrompt = null; }); return; }
    var ios = Api.ehIOS(), android = /Android/i.test(navigator.userAgent), txt;
    if (ios) txt = '<p>No Safari:</p><p>1. Toque no botão <b>Compartilhar</b> (o quadrado com a seta para cima, embaixo no centro).<br>2. Role e toque em <b>Adicionar à Tela de Início</b>.<br>3. Toque em <b>Adicionar</b>.</p><p>O ícone do ' + h(CFG.APP_NAME) + ' aparece na tela inicial como um app.</p>';
    else if (android) txt = '<p>No Chrome:</p><p>1. Toque nos <b>três pontinhos</b> no canto superior direito.<br>2. Toque em <b>Adicionar à tela inicial</b> (ou <b>Instalar app</b>).<br>3. Confirme em <b>Adicionar</b>.</p>';
    else txt = '<p>No Chrome do computador:</p><p>1. Clique nos <b>três pontinhos</b> no canto superior direito.<br>2. Vá em <b>Salvar e compartilhar</b> e clique em <b>Criar atalho</b> (ou <b>Instalar página como app</b>).<br>3. Marque <b>Abrir como janela</b> e confirme.</p>';
    dialogo('<h3>Instalar ' + h(CFG.APP_NAME) + '</h3>' + txt + '<div class="dialogo-botoes"><button class="btn btn-dourado" id="dg-ok" data-focusable>Entendi</button></div>', function () { $('dg-ok').onclick = fecharDialogo; });
  }
  function dialogoTransmitir() {
    var ios = Api.ehIOS(), android = /Android/i.test(navigator.userAgent), txt;
    if (ios) txt = '<p><b>Só o vídeo:</b> abra um canal ou filme e toque no ícone de transmitir dentro do player (AirPlay).</p><p><b>O app inteiro:</b> abra a Central de Controle do iPhone, toque em <b>Espelhamento de Tela</b> e escolha a TV.</p>';
    else if (android) txt = '<p><b>Só o vídeo:</b> abra um canal ou filme e toque no ícone de transmitir dentro do player (Chromecast).</p><p><b>O app inteiro:</b> puxe a barra de notificações e toque em <b>Transmitir tela</b> (ou <b>Smart View</b> em Samsung), depois escolha a TV.</p>';
    else txt = '<p><b>Só o vídeo:</b> abra um canal ou filme e toque no ícone de transmitir dentro do player.</p><p><b>O app inteiro:</b> no Chrome, clique nos três pontinhos, depois em <b>Transmitir, salvar e compartilhar</b> e em <b>Transmitir</b>, escolhendo a TV e a opção <b>Tela inteira</b> ou <b>Guia</b>.</p>';
    dialogo('<h3>Transmitir para a TV</h3>' + txt + '<div class="dialogo-botoes"><button class="btn btn-dourado" id="dg-ok" data-focusable>Entendi</button></div>', function () { $('dg-ok').onclick = fecharDialogo; });
  }
  function verificarAtualizacao() {
    if (location.protocol === 'file:') return;
    fetch('version.json?_=' + Date.now(), { cache: 'no-store' }).then(function (r) { return r.json(); }).then(function (v) {
      if (v && v.versao && v.versao !== VERSAO_TELAS && sessionStorage.getItem('telavip_atualizou') !== v.versao) {
        sessionStorage.setItem('telavip_atualizou', v.versao);
        toast('Atualizando o app para a versão ' + v.versao + '...', 4000);
        var limpar = window.caches ? caches.keys().then(function (ks) { return Promise.all(ks.map(function (k) { return caches.delete(k); })); }) : Promise.resolve();
        limpar.then(function () { setTimeout(function () { location.reload(); }, 1200); });
      }
    }).catch(function () {});
  }

  function sair() {
    confirmar('Sair', 'Isso desconecta este aparelho. O código continua o mesmo e pode ser reativado pelo painel.', 'Sair').then(function (ok) {
      if (!ok) return;
      Store.setLiberacao(null); E.cat = null; E.lib = null;
      mostrarTela('ativacao'); verificarAtivacao(false);
    });
  }

  // ============ LISTA ============
  function listaAtual() {
    return listaDaLiberacao(E.lib);
  }
  function carregarCatalogo() {
    var l = listaAtual();
    var msgEl = $('carregando-msg'); $('carregando-tentar').classList.add('oculta');
    if (!l) { mostrarSemLista('Nenhuma lista cadastrada para este aparelho. Fale com o suporte.'); return; }
    msgEl.textContent = 'Carregando "' + l.nome + '"...';
    Api.carregarLista(l.link, function (m) { msgEl.textContent = m; }).then(function (cat) {
      E.cat = cat; E.selecao = {}; E.busca = {};
      aplicarExtras();
      mostrarTela('app'); ir('inicio', null, true);
      if (E.lib) setTimeout(function () { mostrarMensagensNovas(E.lib); }, 800);
    }).catch(function (e) {
      msgEl.textContent = 'Não consegui carregar a lista: ' + (e.message || e);
      $('carregando-tentar').classList.remove('oculta'); $('carregando-tentar').focus();
    });
  }

  // canais criados por você na aba "CANAIS EXTRAS" da planilha
  function aplicarExtras() {
    if (!E.cat) return;
    E.cat.live.cats = E.cat.live.cats.filter(function (c) { return c.id !== 'extra'; });
    E.cat.live.itens = E.cat.live.itens.filter(function (i) { return i.cat !== 'extra'; });
    var lista = (E.lib && E.lib.canais_extras) || [];
    if (!lista.length) return;
    var nomeExtras = (E.lib.config && E.lib.config.nome_extras) || '\u2747\uFE0F PEDIDOS';
    E.cat.live.cats.unshift({ id: 'extra', nome: nomeExtras, nomeLimpo: nomeExtras });
    var novos = lista.map(function (x, i) {
      return { id: 'x' + i, nome: x.nome || ('Canal ' + (i + 1)), logo: x.logo || '', cat: 'extra', epgId: '', url: x.link, tipo: 'live', extra: true, grupo: x.grupo || '' };
    });
    E.cat.live.itens = novos.concat(E.cat.live.itens);
  }
  // devolve o endereço normal da página (para abrir fora do modo embutido)
  function paginaOriginal(url) {
    var u = String(url || '');
    var yt = u.match(/(?:youtube\.com\/(?:watch\?v=|live\/|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
    if (yt) return 'https://m.youtube.com/watch?v=' + yt[1];
    return u;
  }
  function linkWeb(url) {
    var u = String(url || '');
    var yt = u.match(/(?:youtube\.com\/(?:watch\?v=|live\/|embed\/|shorts\/)|youtu\.be\/)([A-Za-z0-9_-]{6,})/);
    if (yt) return 'https://www.youtube.com/embed/' + yt[1] + '?autoplay=1&playsinline=1&rel=0';
    if (/\.(m3u8|ts|mp4|mkv)(\?|$)/i.test(u) || /get\.php|\/live\/|\/movie\//i.test(u)) return null; // vídeo direto
    if (/vimeo\.com\/(\d+)/.test(u)) return 'https://player.vimeo.com/video/' + u.match(/vimeo\.com\/(\d+)/)[1] + '?autoplay=1';
    if (/^https?:\/\//i.test(u)) return u;   // qualquer página (abre dentro do app)
    return null;
  }

  // ============ NAVEGAÇÃO ============
  function ir(rota, params, semHistorico) {
    if (E.rota && !semHistorico && (E.rota !== rota || JSON.stringify(E.params) !== JSON.stringify(params))) E.pilha.push({ rota: E.rota, params: E.params });
    if (E.pilha.length > 30) E.pilha.shift();
    E.rota = rota; E.params = params || null;
    pararPreview();
    document.querySelectorAll('.topo-nav button, .nav-mobile button').forEach(function (b) { b.classList.toggle('ativo', b.getAttribute('data-rota') === rota); });
    var v = $('view'); v.scrollTop = 0;
    var r = { inicio: telaInicio, canais: function () { telaCanais('canais'); }, jogos: function () { telaCanais('jogos'); }, filmes: function () { telaCatalogo('vod'); }, series: function () { telaCatalogo('series'); }, infantil: telaInfantil, perfil: telaPerfil, listas: telaListas, config: telaConfig, filme: telaFilme, serie: telaSerie };
    (r[rota] || telaInicio)();
    filaCapas = [];
    ligarImagens(v);
    var f = v.querySelector('[data-focusable]'); if (f && document.body.classList.contains('modo-tv')) f.focus();
  }
  function voltar() {
    if (!E.pilha.length) { if (E.rota !== 'inicio') ir('inicio', null, true); return; }
    var p = E.pilha.pop(); ir(p.rota, p.params, true);
  }

  // ============ utilidades de catálogo ============
  function ehAdulto(nome) { nome = String(nome || '').toLowerCase(); return CFG.PALAVRAS_ADULTO.some(function (p) { return nome.indexOf(p) !== -1; }); }
  function ehEsporte(nome) { nome = String(nome || '').toLowerCase(); return CFG.PALAVRAS_ESPORTE.some(function (p) { return nome.indexOf(p) !== -1; }); }
  function ehInfantil(nome) { nome = String(nome || '').toLowerCase(); var pal = (E.lib && E.lib.config && E.lib.config.palavras_infantil) || ['infantil', 'kids', 'desenho']; return pal.some(function (p) { return p && nome.indexOf(p) !== -1; }); }
  function catsVisiveis(tipo) {
    var cfg = Store.config(), ocultas = (cfg.catsOcultas && cfg.catsOcultas[tipo]) || [];
    return E.cat[tipo].cats.filter(function (c) { return ocultas.indexOf(c.id) === -1 && (E.adultoLiberado || !ehAdulto(c.nome)); });
  }
  function itensDaCat(tipo, catId) {
    var vis = catsVisiveis(tipo).map(function (c) { return c.id; });
    return E.cat[tipo].itens.filter(function (i) { return catId === '*' ? vis.indexOf(i.cat) !== -1 : i.cat === catId; });
  }
  function nomeCat(tipo, id) { var c = E.cat[tipo].cats.find(function (x) { return x.id === id; }); return c ? c.nomeLimpo : ''; }
  // últimos filmes/séries que o cliente abriu (vale para qualquer lista)
  function recentesTipo(tipo) {
    var prog = Store.progresso();
    var chaves = Object.keys(prog).sort(function (a, b) { return prog[b].quando - prog[a].quando; });
    var ids = [], vistos = {};
    chaves.forEach(function (k) {
      if (tipo === 'vod' && k.indexOf('vod:') === 0) { var id = k.slice(4); if (!vistos[id]) { vistos[id] = 1; ids.push(id); } }
      if (tipo === 'series' && k.indexOf('ep:') === 0) { var r = prog[k].ref; if (r && r.serieId && !vistos[r.serieId]) { vistos[r.serieId] = 1; ids.push(String(r.serieId)); } }
    });
    return ids.map(function (id) { return porId(tipo, id); }).filter(Boolean);
  }

  function buscarItens(tipo, texto) {
    texto = texto.toLowerCase().trim(); if (!texto) return [];
    var vis = catsVisiveis(tipo).map(function (c) { return c.id; });
    return E.cat[tipo].itens.filter(function (i) { return i.nome.toLowerCase().indexOf(texto) !== -1 && vis.indexOf(i.cat) !== -1; }).slice(0, 300);
  }
  function porId(tipo, id) { return E.cat[tipo].itens.find(function (i) { return i.id === String(id); }); }
  // O config.js fica dentro do APK e nunca é atualizado, então a versão dele
  // envelhece. A versão de verdade das telas está no version.json do app.zip.
  var VERSAO_TELAS = window.TELAVIP_BUILD || CFG.VERSAO;
  function lerVersaoTelas() {
    try {
      fetch('version.json?_=' + Date.now(), { cache: 'no-store' })
        .then(function (r) { return r.json(); })
        .then(function (v) {
          if (v && v.versao) {
            VERSAO_TELAS = String(v.versao);
            document.querySelectorAll('[data-versao]').forEach(function (el) { el.textContent = VERSAO_TELAS; });
          }
        }).catch(function () {});
    } catch (e) {}
  }

  var IMG_VAZIA = 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
  function imgOuNada(src) { return src ? h(src) : IMG_VAZIA; }
  // devolve os atributos de uma capa que só será pedida quando chegar perto da tela
  function imgAdiada(src) {
    return src ? ('src="' + IMG_VAZIA + '" data-capa="' + h(src) + '"') : ('src="' + IMG_VAZIA + '"');
  }

  // ---- capas: pede só o que está à vista e poucas de cada vez ----
  // servidor de IPTV corta quando recebe centenas de pedidos juntos, e a grade
  // inteira demorava minutos para aparecer
  var filaCapas = [], baixandoCapas = 0, MAX_CAPAS = 6, olheiro = null;
  function proximaCapa() {
    while (baixandoCapas < MAX_CAPAS && filaCapas.length) {
      var img = filaCapas.shift();
      if (!img || !img.getAttribute || !img.getAttribute('data-capa') || !document.body.contains(img)) continue;
      var url = img.getAttribute('data-capa');
      img.removeAttribute('data-capa');
      baixandoCapas++;
      (function (el) {
        var terminou = function (ok) {
          el.onload = null; el.onerror = null;
          if (!ok) el.style.visibility = 'hidden';
          baixandoCapas--;
          proximaCapa();
        };
        el.onload = function () { terminou(true); };
        el.onerror = function () { terminou(false); };
        el.src = url;
      })(img);
    }
  }
  function ligarImagens(raiz) {
    var alvos = (raiz || document).querySelectorAll('img[data-capa]');
    if (!alvos.length) return;
    filaCapas = filaCapas.filter(function (x) { return document.body.contains(x); });
    if (!window.IntersectionObserver) {
      for (var i = 0; i < alvos.length; i++) filaCapas.push(alvos[i]);
      proximaCapa();
      return;
    }
    if (!olheiro) {
      olheiro = new IntersectionObserver(function (entradas) {
        for (var k = 0; k < entradas.length; k++) {
          if (!entradas[k].isIntersecting) continue;
          olheiro.unobserve(entradas[k].target);
          filaCapas.push(entradas[k].target);
        }
        proximaCapa();
      }, { rootMargin: '400px' });
    }
    for (var j = 0; j < alvos.length; j++) olheiro.observe(alvos[j]);
  }

  function cardVod(item) {
    var p = Store.lerProgresso('vod:' + item.id), prog = p && p.dur ? Math.round(p.pos / p.dur * 100) : 0;
    return '<button class="card" data-focusable data-abrir="filme" data-id="' + h(item.id) + '"><img ' + imgAdiada(item.capa) + ' alt="">' + (item.nota ? '<span class="nota">&#9733; ' + item.nota.toFixed(1) + '</span>' : '') + (prog ? '<span class="progresso"><i style="width:' + prog + '%"></i></span>' : '') + '<span class="card-nome">' + h(item.nome) + '</span></button>';
  }
  function cardSerie(item) {
    return '<button class="card" data-focusable data-abrir="serie" data-id="' + h(item.id) + '"><img ' + imgAdiada(item.capa) + ' alt="">' + (item.nota ? '<span class="nota">&#9733; ' + item.nota.toFixed(1) + '</span>' : '') + '<span class="card-nome">' + h(item.nome) + '</span></button>';
  }
  function cardCanal(item) {
    return '<button class="card canal" data-focusable data-abrir="canal" data-id="' + h(item.id) + '"><img ' + imgAdiada(item.logo) + ' alt=""><span class="card-nome">' + h(item.nome) + '</span></button>';
  }
  function ligarCards(raiz) {
    ligarImagens(raiz);
    raiz.querySelectorAll('[data-abrir]').forEach(function (b) {
      b.addEventListener('click', function () {
        var t = b.getAttribute('data-abrir'), id = b.getAttribute('data-id');
        if (t === 'filme') ir('filme', { id: id });
        else if (t === 'serie') ir('serie', { id: id });
        else if (t === 'canal') { var c = porId('live', id); if (c) tocarCanal(c, itensDaCat('live', c.cat)); }
        else if (t === 'progresso') abrirProgresso(id);
      });
    });
  }

  // ============ INÍCIO ============
  function telaInicio() {
    var v = $('view'), lib = E.lib || {}, cfgP = lib.config || {}, html = '';
    var vistas = Store.mensagensVistas();
    if (lib.mensagem_cliente && vistas.individual !== lib.mensagem_cliente) html += '<div class="aviso-msg"><b>Mensagem do suporte</b>' + h(lib.mensagem_cliente) + '</div>';
    if (cfgP.mensagem_aviso && vistas.geral !== cfgP.mensagem_aviso) html += '<div class="aviso-painel">' + h(cfgP.mensagem_aviso) + '</div>';
    if (lib.aviso_vencimento_texto) html += '<div class="aviso-vencimento">' + h(lib.aviso_vencimento_texto) + '</div>';
    else if (lib.aviso_vencimento) html += '<div class="aviso-vencimento">Sua assinatura vence em ' + h(lib.validade) + '. Fale com o suporte para renovar.</div>';

    var ultimosVod = itensDaCat('vod', '*').slice().sort(function (a, b) { return b.added - a.added; }).slice(0, 8);
    if (ultimosVod.length) {
      html += '<div class="hero" id="hero"><div class="hero-fundo" id="hero-fundo"></div><div class="hero-grad"></div><div class="hero-conteudo" id="hero-conteudo"></div><div class="hero-pontos" id="hero-pontos"></div></div>';
    }
    if (document.body.classList.contains('modo-tv')) {
      html += '<div class="cards-tv"><button data-rota="canais" data-focusable><i>&#128250;</i>Canais</button><button data-rota="filmes" data-focusable><i>&#127916;</i>Filmes</button><button data-rota="series" data-focusable><i>&#127909;</i>Séries</button><button data-rota="jogos" data-focusable><i>&#9917;</i>Jogos</button><button data-rota="infantil" data-focusable><i>&#129409;</i>Infantil</button></div>';
    }
    if (cfgP.banner_url) html += '<div class="banner-painel"><img src="' + h(cfgP.banner_url) + '" alt=""></div>';

    // jogos de hoje (preenchido depois, pelo guia dos canais de esporte)
    if (E.cat.tipo === 'xtream' && catsVisiveis('live').some(function (c) { return ehEsporte(c.nome); })) html += '<div class="secao" id="sec-jogos"><h2>&#127942; Jogos de hoje</h2><div class="faixa" id="faixa-jogos"><div class="vazio" style="padding:.6em">Buscando jogos no guia...</div></div></div>';
    var porRecente = function (a, b) { return b.added - a.added; };
    var catsLanc = catsVisiveis('vod').filter(function (c) { return /lan[çc]amento/i.test(c.nome); });
    var lanc = [].concat.apply([], catsLanc.map(function (c) { return itensDaCat('vod', c.id); })).sort(porRecente).slice(0, 10);
    if (lanc.length) html += '<div class="secao"><h2>&#10024; Lançamentos</h2><div class="faixa">' + lanc.map(cardVod).join('') + '</div></div>';
    if (ultimosVod.length) html += '<div class="secao"><h2>Últimos filmes <small>adicionados recentemente</small></h2><div class="faixa">' + itensDaCat('vod', '*').slice().sort(porRecente).slice(0, 10).map(cardVod).join('') + '</div></div>';
    var ultSeries = itensDaCat('series', '*').slice().sort(porRecente).slice(0, 10);
    if (ultSeries.length) html += '<div class="secao"><h2>Últimas séries</h2><div class="faixa">' + ultSeries.map(cardSerie).join('') + '</div></div>';
    if (!E.cat.vod.itens.length && !E.cat.series.itens.length && E.cat.live.itens.length) {
      html += '<div class="secao"><h2>Canais</h2><div class="faixa">' + itensDaCat('live', '*').slice(0, 30).map(cardCanal).join('') + '</div></div>';
    }
    html += '<div class="rodape-app"><span>' + (lib.nome ? h(lib.nome) + ' · ' : '') + (lib.validade ? 'Válido até ' + h(lib.validade) : '') + '</span><span>' + (lib.config && lib.config.whatsapp ? '<a href="' + h(lib.config.whatsapp) + '" target="_blank">Suporte no WhatsApp</a> · ' : '') + h(CFG.APP_NAME) + ' v<span data-versao>' + h(VERSAO_TELAS) + '</span></span></div>';
    v.innerHTML = html;
    v.querySelectorAll('[data-rota]').forEach(function (b) { b.addEventListener('click', function () { ir(b.getAttribute('data-rota')); }); });
    ligarCards(v);
    if (ultimosVod.length) montarHero(ultimosVod);
    if ($('faixa-jogos')) montarJogosDoDia();
  }

  // Lê o guia dos canais de esporte e monta os cards "time x time"
  var cacheJogos = null;
  function montarJogosDoDia() {
    var faixa = $('faixa-jogos'); if (!faixa) return;
    if (cacheJogos && Date.now() - cacheJogos.quando < 15 * 60 * 1000) { renderJogos(cacheJogos.jogos); return; }
    var catsEsp = catsVisiveis('live').filter(function (c) { return ehEsporte(c.nome); });
    var canais = [].concat.apply([], catsEsp.map(function (c) { return itensDaCat('live', c.id); }));
    // uma variante por canal (evita HD/FHD/SD repetidos) e no máximo 60 consultas
    var vistos = {}, unicos = [];
    canais.forEach(function (c) { var b = separarQualidade(c.nome).base; if (!vistos[b]) { vistos[b] = true; unicos.push(c); } });
    unicos = unicos.slice(0, 60);
    var jogos = [], pendentes = unicos.length, agora = Date.now(), fimDia = new Date(); fimDia.setHours(23, 59, 59, 999);
    var RX = /^(?:(.*?)[:|\-–]\s*)?(.+?)\s+(?:x|vs\.?|v)\s+(.+?)$/i;

    // 1) canais cujo nome já é o jogo: "03 - 10:30h - Hoffenheim x Borussia" (categorias tipo JOGOS DO DIA)
    var RX_NOME = /^(?:\d{1,3}\s*[-–.:]\s*)?(\d{1,2})[:h.](\d{2})?\s*h?\s*[-–:|]?\s*(.+?)\s+(?:x|vs\.?)\s+(.+?)\s*$/i;
    catsEsp.filter(function (c) { return /jogo|partida|evento|ppv|hoje/i.test(c.nome); }).forEach(function (cat) {
      itensDaCat('live', cat.id).forEach(function (c) {
        var m = String(c.nome).replace(/\s+/g, ' ').trim().match(RX_NOME);
        if (!m) return;
        var ini = new Date(); ini.setHours(+m[1], +(m[2] || 0), 0, 0);
        var liga = '', ta = m[3].trim(), tb = m[4].trim(), ml = ta.match(/^(.*?)[:|\-–]\s*(.+)$/);
        if (ml && ml[2].length > 2) { liga = ml[1].trim(); ta = ml[2].trim(); }
        if (ta.length > 40 || tb.length > 40) return;
        var chave = (ta + '|' + tb).toLowerCase();
        var j = jogos.find(function (x) { return x.chave === chave; });
        if (j) { j.canais.push(c.nome); j.canaisIds.push(c.id); return; }
        jogos.push({ chave: chave, liga: liga || cat.nomeLimpo, a: ta, b: tb, inicio: ini.getTime(), fim: ini.getTime() + 2 * 3600000, canais: [c.nome], canaisIds: [c.id] });
      });
    });
    if (jogos.length) { jogos.sort(function (x, y) { return x.inicio - y.inicio; }); renderJogos(jogos.slice()); }

    // 2) guia de programação dos canais de esporte
    if (!pendentes) { cacheJogos = { quando: Date.now(), jogos: jogos }; renderJogos(jogos); return; }
    unicos.forEach(function (c) {
      Api.epgCanal(E.cat, c.id, 6).then(function (epg) {
        epg.forEach(function (p) {
          if (p.fim < agora || p.inicio > fimDia.getTime()) return;
          var t = String(p.titulo || '').replace(/\s+/g, ' ').trim(), m = t.match(RX);
          if (!m || m[2].length > 40 || m[3].length > 40) return;
          var chave = (m[2] + '|' + m[3]).toLowerCase();
          var j = jogos.find(function (x) { return x.chave === chave; });
          if (j) { if (j.canais.indexOf(c.nome) === -1) j.canais.push(c.nome); if (j.canaisIds.indexOf(c.id) === -1) j.canaisIds.push(c.id); return; }
          jogos.push({ chave: chave, liga: (m[1] || nomeCat('live', c.cat) || '').trim(), a: m[2].trim(), b: m[3].trim(), inicio: p.inicio, fim: p.fim, canais: [c.nome], canaisIds: [c.id] });
        });
      }).catch(function () {}).then(function () {
        pendentes--;
        if (pendentes === 0) { jogos.sort(function (x, y) { return x.inicio - y.inicio; }); cacheJogos = { quando: Date.now(), jogos: jogos }; renderJogos(jogos); }
      });
    });
  }
  function renderJogos(jogos) {
    var faixa = $('faixa-jogos'), sec = $('sec-jogos'); if (!faixa) return;
    if (!jogos.length) { if (sec) sec.remove(); return; }
    var agora = Date.now();
    jogos = jogos.filter(function (j) { return j.fim > agora - 3600000; }).concat(jogos.filter(function (j) { return j.fim <= agora - 3600000; }));
    faixa.innerHTML = jogos.slice(0, 20).map(function (j, i) {
      var live = j.inicio <= agora && j.fim > agora;
      return '<button class="jogo ' + (live ? 'aovivo' : '') + '" data-focusable data-jogo="' + i + '"><div class="jogo-liga">' + h(j.liga || 'Futebol') + '</div><div class="jogo-campo"><div class="jogo-time">' + h(j.a) + '</div><div class="jogo-vs"><span>VS</span><b>' + hora(j.inicio) + '</b></div><div class="jogo-time">' + h(j.b) + '</div></div><div class="jogo-canal"><b>' + h(j.canais[0]) + '</b>' + (j.canais.length > 1 ? ' +' + (j.canais.length - 1) : '') + '</div></button>';
    }).join('');
    faixa.querySelectorAll('[data-jogo]').forEach(function (b) {
      b.addEventListener('click', function () {
        var j = jogos[+b.getAttribute('data-jogo')];
        if (j.canaisIds.length === 1) { var c = porId('live', j.canaisIds[0]); if (c) tocarCanal(c, itensDaCat('live', c.cat)); return; }
        dialogo('<h3>' + h(j.a) + ' x ' + h(j.b) + '</h3><p>' + hora(j.inicio) + ' · escolha o canal:</p><div class="lista-simples">' + j.canaisIds.map(function (id, k) { return '<button data-c="' + h(id) + '" data-focusable><b>' + h(j.canais[k]) + '</b></button>'; }).join('') + '</div><div class="dialogo-botoes"><button class="btn" id="dg-nao" data-focusable>Cancelar</button></div>', function (cx) {
          cx.querySelectorAll('[data-c]').forEach(function (x) { x.addEventListener('click', function () { fecharDialogo(); var c = porId('live', x.getAttribute('data-c')); if (c) tocarCanal(c, itensDaCat('live', c.cat)); }); });
          $('dg-nao').onclick = fecharDialogo;
        });
      });
    });
  }

  var heroTimer = null, heroInfo = {};
  function montarHero(itens) {
    var i = 0;
    function mostrar(idx) {
      i = idx; var it = itens[i];
      var info = heroInfo[it.id] || {};
      var fundo = info.fundo || it.capa;
      $('hero-fundo').style.backgroundImage = fundo ? 'url("' + fundo + '")' : 'none';
      $('hero-conteudo').innerHTML = '<h1>' + h(it.nome) + '</h1><div class="hero-meta"><span>Filme</span>' + (info.genero ? '<span>' + h(info.genero) + '</span>' : '<span>' + h(nomeCat('vod', it.cat)) + '</span>') + (it.nota ? '<span><b>&#9733; ' + it.nota.toFixed(1) + '</b></span>' : '') + (info.duracao ? '<span>' + h(info.duracao) + '</span>' : '') + '</div><div class="hero-sinopse">' + h(info.sinopse || '') + '</div><div class="hero-botoes"><button class="btn btn-dourado" id="hero-assistir" data-focusable>&#9654; Assistir</button><button class="btn" id="hero-fav" data-focusable>' + (coracao(Store.ehFavorito('vod', it.id)) + (Store.ehFavorito('vod', it.id) ? ' Favorito' : ' Favoritar')) + '</button><button class="btn" id="hero-mais" data-focusable>Detalhes</button></div>';
      $('hero-pontos').innerHTML = itens.map(function (_, k) { return '<i class="' + (k === i ? 'ativo' : '') + '"></i>'; }).join('');
      $('hero-assistir').onclick = function () { tocarFilme(it); };
      $('hero-mais').onclick = function () { ir('filme', { id: it.id }); };
      $('hero-fav').onclick = function () { var on = Store.alternarFavorito('vod', it.id); $('hero-fav').innerHTML = coracao(on) + (on ? ' Favorito' : ' Favoritar'); };
      if (!heroInfo[it.id]) {
        Api.vodInfo(E.cat, it.id).then(function (r) {
          var inf = (r && r.info) || {};
          heroInfo[it.id] = { sinopse: inf.plot || inf.description || '', genero: inf.genre || '', duracao: inf.duration || '', fundo: (inf.backdrop_path && inf.backdrop_path[0]) || '' };
          if (i === idx && $('hero-conteudo')) mostrar(idx);
        });
      }
    }
    mostrar(0);
    clearInterval(heroTimer);
    heroTimer = setInterval(function () { if (!$('hero') || E.rota !== 'inicio') { clearInterval(heroTimer); return; } if (document.activeElement && $('hero').contains(document.activeElement)) return; mostrar((i + 1) % itens.length); }, 8000);
  }

  function abrirProgresso(chave) {
    var p = Store.lerProgresso(chave); if (!p) return;
    if (chave.indexOf('vod:') === 0) { var it = porId('vod', chave.slice(4)); if (it) tocarFilme(it); else toast('Este filme não está mais na lista'); }
    else if (p.ref && p.ref.serieId) { ir('serie', { id: p.ref.serieId, temporada: p.ref.temporada, epId: chave.slice(3) }); }
  }

  // ============ CANAIS ============
  function telaCanais(modo) {
    var v = $('view');
    var cats = catsVisiveis('live');
    if (modo === 'jogos') cats = cats.filter(function (c) { return ehEsporte(c.nome); });
    var sel = E.selecao[modo] || (modo === 'jogos' ? (cats[0] ? cats[0].id : '*') : '*');
    E.selecao[modo] = sel;
    var html = '<div class="canais"><div class="canais-col canais-cats" id="cn-cats"></div><div class="canais-col" id="cn-lista"></div><div class="canais-col canais-preview" id="cn-preview"><div class="preview"><div class="preview-video" id="pv-wrap"><video id="pv-video" muted playsinline></video><div class="preview-msg" id="pv-msg">Escolha um canal</div></div><div id="pv-info"></div></div></div></div>';
    v.innerHTML = html;
    var catsEl = $('cn-cats');
    var chtml = '<input class="busca" id="cn-busca" data-focusable tabindex="0" placeholder="Buscar canal..." value="' + h(E.busca[modo] || '') + '">';
    if (modo !== 'jogos') { chtml += '<button class="cat-btn ' + (sel === 'fav' ? 'ativo' : '') + '" data-cat="fav" data-focusable>\u2764\uFE0F FAVORITOS</button><button class="cat-btn ' + (sel === 'rec' ? 'ativo' : '') + '" data-cat="rec" data-focusable>\uD83C\uDF00 VISTO RECENTE</button><button class="cat-btn ' + (sel === '*' ? 'ativo' : '') + '" data-cat="*" data-focusable>\u2734\uFE0F TODOS CANAIS</button>'; }
    chtml += cats.map(function (c) { return '<button class="cat-btn ' + (sel === c.id ? 'ativo' : '') + '" data-cat="' + h(c.id) + '" data-focusable>' + h(c.nomeLimpo) + '</button>'; }).join('');
    if (modo === 'jogos' && !cats.length) chtml += '<div class="vazio">Nenhuma categoria de esportes nesta lista.</div>';
    catsEl.innerHTML = chtml;
    catsEl.querySelectorAll('[data-cat]').forEach(function (b) { b.addEventListener('click', function () { E.selecao[modo] = b.getAttribute('data-cat'); E.busca[modo] = ''; catsEl.querySelectorAll('.cat-btn').forEach(function (x) { x.classList.toggle('ativo', x === b); }); renderCanais(modo); }); });
    $('cn-busca').addEventListener('input', function () { E.busca[modo] = this.value; renderCanais(modo); });
    E.preview = Player.Motor($('pv-video'));
    renderCanais(modo);
  }
  function listaCanaisAtual(modo) {
    var sel = E.selecao[modo], busca = E.busca[modo];
    if (busca) return buscarItens('live', busca);
    if (sel === 'fav') return Store.favoritos().live.map(function (id) { return porId('live', id); }).filter(Boolean);
    if (sel === 'rec') return Store.canaisRecentes().map(function (id) { return porId('live', id); }).filter(Boolean);
    return itensDaCat('live', sel);
  }
  function renderCanais(modo) {
    var lista = listaCanaisAtual(modo), el = $('cn-lista'); if (!el) return;
    var selAtual = E.selecao[modo];
    var tituloLista = E.busca[modo] ? 'Resultado' : (selAtual === '*' ? 'Todos' : (selAtual === 'fav' ? 'Favoritos' : (selAtual === 'rec' ? 'Visto recente' : nomeCat('live', selAtual))));
    var cabecalho = '<h2 class="canais-total">' + h(tituloLista || 'Canais') + ' (' + lista.length + ')</h2>';
    if (!lista.length) { el.innerHTML = cabecalho + '<div class="vazio"><strong>Nada por aqui</strong>' + (E.selecao[modo] === 'fav' ? 'Toque no coração de um canal para adicionar aos favoritos.' : 'Nenhum canal nesta categoria.') + '</div>'; return; }
    var fav = Store.favoritos().live;
    el.innerHTML = cabecalho + lista.slice(0, 600).map(function (c) {
      return '<div class="canal-linha" data-id="' + h(c.id) + '" data-focusable tabindex="0"><img ' + imgAdiada(c.logo) + ' alt=""><div class="canal-info"><div class="canal-nome">' + h(c.nome) + '</div><div class="canal-epg" data-epg="' + h(c.id) + '"></div></div><button class="canal-fav ' + (fav.indexOf(c.id) !== -1 ? 'on' : '') + '" data-fav="' + h(c.id) + '" data-focusable title="Favoritar">' + ICO_CORACAO + '</button></div>';
    }).join('') + (lista.length > 600 ? '<div class="vazio">Mostrando 600 de ' + lista.length + '. Use a busca.</div>' : '');
    el.querySelectorAll('.canal-linha').forEach(function (linha) {
      var id = linha.getAttribute('data-id');
      linha.addEventListener('click', function (e) {
        if (e.target.closest('[data-fav]')) return;
        var c = porId('live', id); if (!c) return;
        var previewVisivel = $('cn-preview') && getComputedStyle($('cn-preview')).display !== 'none';
        if (!previewVisivel || linha.classList.contains('ativo')) { tocarCanal(c, lista); return; }
        el.querySelectorAll('.canal-linha').forEach(function (x) { x.classList.remove('ativo'); }); linha.classList.add('ativo');
        previewCanal(c);
      });
      linha.addEventListener('keydown', function (e) { if (e.key === 'Enter') { e.preventDefault(); linha.click(); } });
    });
    el.querySelectorAll('[data-fav]').forEach(function (b) { b.addEventListener('click', function (e) { e.stopPropagation(); var on = Store.alternarFavorito('live', b.getAttribute('data-fav')); b.classList.toggle('on', on); toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos'); if (E.selecao[modo] === 'fav' && !on) renderCanais(modo); }); });
    // EPG "agora" para os primeiros canais visíveis
    if (E.cat.tipo === 'xtream') lista.slice(0, 25).forEach(function (c) { Api.epgCanal(E.cat, c.id, 2).then(function (epg) { var d = el.querySelector('[data-epg="' + c.id + '"]'); if (!d) return; var agora = epg.find(function (p) { return p.inicio <= Date.now() && p.fim > Date.now(); }) || epg[0]; if (agora) d.textContent = agora.titulo; }); });
  }
  function previewCanal(c) {
    pararPreview(false);
    if (c.extra) {
      $('pv-msg').textContent = 'Toque de novo para abrir este canal.'; $('pv-msg').style.display = 'flex';
      $('pv-info').innerHTML = '<div class="preview-cab"><img src="' + imgOuNada(c.logo) + '" alt=""><strong>' + h(c.nome) + '</strong></div><button class="btn btn-dourado" id="pv-abrir" data-focusable style="width:100%">Assistir</button>';
      $('pv-abrir').onclick = function () { tocarCanal(c, null); };
      return;
    }
    $('pv-msg').textContent = 'Carregando...'; $('pv-msg').style.display = 'flex';
    var cfg = Store.config(), fmt = Api.formatoEfetivo(cfg.formato);
    E.preview.tocar(Api.urlLive(E.cat, c, fmt), function () { var alt = fmt === 'ts' ? 'm3u8' : 'ts'; E.preview.tocar(Api.urlLive(E.cat, c, alt), function () { $('pv-msg').textContent = 'Sem sinal na pré-visualização. Toque de novo para abrir em tela cheia.'; }); });
    var vid = $('pv-video'); vid.onplaying = function () { $('pv-msg').style.display = 'none'; };
    var info = $('pv-info');
    info.innerHTML = '<div class="preview-cab"><img src="' + imgOuNada(c.logo) + '" alt=""><strong>' + h(c.nome) + '</strong><span class="aovivo">&#9679; AO VIVO</span></div><div id="pv-epg"><div class="vazio">Buscando programação...</div></div><button class="btn btn-dourado" id="pv-abrir" data-focusable style="width:100%">Assistir em tela cheia</button>';
    $('pv-abrir').onclick = function () { tocarCanal(c, listaCanaisAtual(E.rota === 'jogos' ? 'jogos' : 'canais')); };
    Api.epgCanal(E.cat, c.id, 6).then(function (epg) {
      var d = $('pv-epg'); if (!d) return;
      if (!epg.length) { d.innerHTML = '<div class="vazio">Sem guia de programação para este canal.</div>'; return; }
      var agora = Date.now();
      d.innerHTML = epg.map(function (p) {
        var ativo = p.inicio <= agora && p.fim > agora, pc = ativo ? Math.round((agora - p.inicio) / (p.fim - p.inicio) * 100) : 0;
        return '<div class="epg-item ' + (ativo ? 'agora' : '') + '"><strong>' + h(p.titulo) + '</strong><span>' + hora(p.inicio) + ' – ' + hora(p.fim) + (ativo ? '' : ' · Próximo') + '</span>' + (ativo ? '<div class="epg-progresso"><i style="width:' + pc + '%"></i></div>' : '') + '</div>';
      }).join('');
    });
  }
  function hora(ms) { var d = new Date(ms); return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  function pararPreview() { if (E.preview) { try { E.preview.parar(); } catch (e) {} } }

  // separa "GLOBO SP FHD" em base "GLOBO SP" e qualidade "FHD"
  var RX_QUAL = /(?:^|[\s\-_|\[\(])((?:FULL\s?HD|FHD|UHD|4K|HD|SD|H\.?265|HEVC|H\.?264)\s?\d?(?:\s?[²³])?|[²³])(?:[\]\)])?\s*$/i;
  function separarQualidade(nome) {
    var n = String(nome || '').trim(), q = '', m;
    while ((m = n.match(RX_QUAL))) { q = (m[1].toUpperCase().replace(/\s+/g, '') + (q ? ' ' + q : '')).trim(); n = n.slice(0, m.index).replace(/[\s\-_|\[\(]+$/, '').trim(); if (!n) { n = nome; break; } }
    return { base: n.toUpperCase().replace(/\s+/g, ' '), qual: q || 'Padrão' };
  }
  function variantesCanal(c, lista) {
    var b = separarQualidade(c.nome).base;
    var v = (lista || itensDaCat('live', c.cat)).filter(function (x) { return separarQualidade(x.nome).base === b; });
    if (v.length < 2) v = itensDaCat('live', c.cat).filter(function (x) { return separarQualidade(x.nome).base === b; });
    if (v.length < 2) v = itensDaCat('live', '*').filter(function (x) { return separarQualidade(x.nome).base === b; });
    return v;
  }
  function rankQualidade(q) {
    q = String(q || '').toUpperCase();
    if (/4K|UHD/.test(q)) return 4;
    if (/FULLHD|FHD/.test(q)) return 3;
    if (/HD/.test(q)) return 2;
    if (/SD/.test(q)) return 1;
    return 0; // Padrão
  }
  // escolhe a variante do canal conforme a preferência (sd | hd | fhd | lista)
  function escolherVariante(c, variantes) {
    var pref = Store.config().qualidade;
    if (pref === 'lista' || !variantes || variantes.length < 2) return c;
    var alvo = pref === 'fhd' ? 3 : (pref === 'hd' ? 2 : 0);
    var melhor = variantes[0], melhorDist = Infinity;
    variantes.forEach(function (v) {
      var r = rankQualidade(separarQualidade(v.nome).qual), d = Math.abs(r - alvo) + (/H\.?265|HEVC/i.test(v.nome) ? 0.4 : 0) + (r > alvo ? 0.2 : 0);
      if (d < melhorDist) { melhorDist = d; melhor = v; }
    });
    return melhor;
  }
  function chaveRank(c) {
    var srv = E.cat && E.cat.tipo === 'xtream' ? E.cat.conta.base : 'm3u';
    return srv + '|' + rankQualidade(separarQualidade(c.nome).qual);
  }
  function playerNativoDisponivel() {
    try { return !!(window.TelaVipNativo && window.TelaVipNativo.abrirPlayerNativo2); } catch (e) { return false; }
  }
  function qualidadeNativa(nome) {
    var q = separarQualidade(nome).qual.toUpperCase();
    if (/FHD|FULLHD|1080/.test(q)) return 'FHD';
    if (/\bHD\b|720/.test(q)) return 'HD';
    if (/SD|PADR|480|360/.test(q)) return 'SD';
    return '';
  }
  function abrirPlayerNativo(fontes, meta) {
    if (!playerNativoDisponivel() || !fontes || !fontes.length) return false;
    try {
      meta = meta || {};
      meta.bufferAlto = Store.config().buffer === 'alto';
      return !!window.TelaVipNativo.abrirPlayerNativo2(JSON.stringify(fontes), JSON.stringify(meta));
    } catch (e) { return false; }
  }

  // No LibVLC não é necessário inventar cinco extensões diferentes como era feito
  // para o player do navegador. O URL informado pelo servidor é sempre a primeira
  // tentativa. Mantemos só HLS e TS como contingência real, reduzindo bastante o
  // tempo de espera quando um filme tem uma extensão que o servidor não aceita.
  function fontesVideoNativo(urls) {
    urls = urls || [];
    var out = [], vistos = {};
    function add(u) { if (!u || vistos[u]) return; vistos[u] = true; out.push(u); }
    if (urls.length) add(urls[0]);
    var hls = urls.find(function (u) { return /\.m3u8(\?|$)/i.test(u); });
    var ts = urls.find(function (u) { return /\.ts(\?|$)/i.test(u); });
    add(hls); add(ts);
    return out;
  }

  function fontesCanalNativo(c, variantes) {
    var ordem = [c].concat((variantes || []).filter(function (x) { return x.id !== c.id; }));
    var out = [], vistos = {};
    ordem.forEach(function (x) {
      var q = qualidadeNativa(x.nome);
      ['ts', 'm3u8'].forEach(function (fmt) {
        var u = Api.urlLive(E.cat, x, fmt);
        if (!u || vistos[u]) return;
        vistos[u] = true;
        out.push({ url: u, qualidade: q, formato: fmt, titulo: x.nome || '' });
      });
    });
    return out;
  }
  function progressoNativo(metaJson, posMs, durMs) {
    var m; try { m = JSON.parse(metaJson || '{}'); } catch (e) { return; }
    if (!m || !m.tipo || !m.id || posMs < 30000) return;
    var pos = posMs / 1000, dur = durMs > 0 ? durMs / 1000 : 0;
    var chave = (m.tipo === 'vod' ? 'vod:' : 'ep:') + m.id;
    if (dur > 0 && pos >= dur * 0.9) {
      Store.removerProgresso(chave);
      if (m.tipo === 'ep') Store.marcarVisto(m.id);
    } else {
      Store.salvarProgresso(chave, { pos: pos, dur: dur, nome: m.titulo || '', capa: m.capa || '', sub: m.sub || '', tipo: m.tipo, ref: m.ref || null });
    }
    if (E.rota) try { ir(E.rota, E.params, true); } catch (e) {}
  }

  function tocarCanal(c, lista, escolhido) {
    pararPreview();
    revalidar(false);
    if (c.extra) {
      var web = linkWeb(c.url);
      // no APK, links da internet abrem em uma tela própria (o YouTube não deixa tocar embutido)
      if (web && window.TelaVipNativo && window.TelaVipNativo.abrirWeb) {
        try { window.TelaVipNativo.abrirWeb(paginaOriginal(c.url)); return; } catch (e) {}
      }
      if (!web && playerNativoDisponivel()) {
        if (abrirPlayerNativo([{ url: c.url, qualidade: qualidadeNativa(c.nome), formato: '' }], { titulo: c.nome, tipo: 'live', id: c.id, favorito: Store.ehFavorito('live', c.id), aoVivo: true, qualidade: qualidadeNativa(c.nome), capa: c.logo || '' })) { Store.registrarCanal(c.id); return; }
      }
      Player.abrir({
        tipo: web ? 'web' : 'live', id: c.id, titulo: c.nome, sub: nomeCat('live', 'extra'), logo: c.logo,
        url: web || c.url, urlOriginal: paginaOriginal(c.url), urlPorFormato: web ? null : function () { return c.url; },
        ehFavorito: function () { return Store.ehFavorito('live', c.id); },
        aoFavoritar: function () { return Store.alternarFavorito('live', c.id); }
      }, function () { if (E.rota === 'canais') ir('canais', null, true); });
      return;
    }
    var variantes = variantesCanal(c, lista);
    if (!escolhido) { var alt = escolherVariante(c, variantes); if (alt && alt.id !== c.id) c = alt; }
    if (playerNativoDisponivel()) {
      var qn = qualidadeNativa(c.nome);
      if (abrirPlayerNativo(fontesCanalNativo(c, variantes), { titulo: c.nome, tipo: 'live', id: c.id, favorito: Store.ehFavorito('live', c.id), aoVivo: true, qualidade: qn, capa: c.logo || '' })) {
        Store.registrarCanal(c.id);
        return;
      }
    }
    var idx = lista ? lista.findIndex(function (x) { return x.id === c.id; }) : -1;
    var dados = {
      tipo: 'live', id: c.id, titulo: c.nome, sub: nomeCat('live', c.cat), lista: lista || [c], indice: idx < 0 ? 0 : idx,
      urlPorFormato: function (fmt) { return Api.urlLive(E.cat, c, fmt); },
      formatoForcado: Store.formatoCanal(c.id) || Store.formatoRank(chaveRank(c)) || E.formatoSessao || null,
      aoTocou: function (fmt) { E.formatoSessao = fmt; Store.setFormatoCanal(c.id, fmt); Store.setFormatoRank(chaveRank(c), fmt); },
      aoNavegar: function (prox) { tocarCanal(prox, lista); },
      aoListaRapida: function () { listaRapida(lista, c); },
      ehFavorito: function () { return Store.ehFavorito('live', c.id); },
      aoFavoritar: function () { return Store.alternarFavorito('live', c.id); },
      aoInfo: function () { Api.epgCanal(E.cat, c.id, 6).then(function (epg) { var agora = Date.now(); dialogo('<h3>' + h(c.nome) + '</h3><p>' + h(nomeCat('live', c.cat)) + '</p>' + (epg.length ? epg.map(function (p) { var at = p.inicio <= agora && p.fim > agora; return '<div class="epg-item ' + (at ? 'agora' : '') + '"><strong>' + h(p.titulo) + '</strong><span>' + hora(p.inicio) + ' – ' + hora(p.fim) + '</span>' + (p.descricao ? '<p style="margin:.3em 0 0">' + h(p.descricao) + '</p>' : '') + '</div>'; }).join('') : '<p>Sem guia de programação.</p>') + '<div class="dialogo-botoes"><button class="btn btn-dourado" id="dg-ok" data-focusable>Fechar</button></div>', function () { $('dg-ok').onclick = fecharDialogo; }); }); },
      logo: c.logo,
      variantes: variantes.map(function (x) { return { id: x.id, rotulo: separarQualidade(x.nome).qual }; }),
      aoQualidadeEscolher: function (id) { var x = porId('live', id); if (x) tocarCanal(x, lista, true); }
    };
    Player.abrir(dados, function () { if (E.rota === 'canais' || E.rota === 'jogos') { var l = document.querySelector('.canal-linha[data-id="' + c.id + '"]'); if (l) l.focus(); } });
    Api.epgCanal(E.cat, c.id, 4).then(function (epg) {
      var at = Player.atual(); if (!at || at.id !== c.id) return;
      var agora = Date.now(), i = epg.findIndex(function (p) { return p.inicio <= agora && p.fim > agora; });
      var a = i >= 0 ? epg[i] : null, prox = i >= 0 ? epg[i + 1] : epg.find(function (p) { return p.inicio > agora; });
      Player.montarEpg(a ? { horas: hora(a.inicio) + '-' + hora(a.fim), titulo: h(a.titulo) } : null, prox ? { horas: hora(prox.inicio), titulo: h(prox.titulo) } : null);
    });
  }
  function listaRapida(lista, atual) {
    var html = '<h3>Canais</h3>' + lista.slice(0, 300).map(function (c) { return '<button class="canal-linha ' + (c.id === atual.id ? 'ativo' : '') + '" data-id="' + h(c.id) + '" data-focusable><img src="' + imgOuNada(c.logo) + '" alt=""><div class="canal-info"><div class="canal-nome">' + h(c.nome) + '</div></div></button>'; }).join('');
    Player.alternarLista(html);
    document.querySelectorAll('#pl-lista [data-id]').forEach(function (b) { b.addEventListener('click', function () { var c = porId('live', b.getAttribute('data-id')); Player.alternarLista(null); if (c) tocarCanal(c, lista); }); });
    var a = document.querySelector('#pl-lista .ativo'); if (a) { a.scrollIntoView({ block: 'center' }); a.focus(); }
  }

  // ============ FILMES / SÉRIES ============
  function telaCatalogo(tipo) {
    var v = $('view'), cats = catsVisiveis(tipo), rotulo = tipo === 'vod' ? 'filme' : 'série';
    var sel = E.selecao[tipo] || (cats[0] ? cats[0].id : '*'); E.selecao[tipo] = sel;
    var rotuloTodos = tipo === 'vod' ? '\u2734\uFE0F TODOS FILMES' : '\u2734\uFE0F TODAS SÉRIES';
    v.innerHTML = '<div class="catalogo"><div class="catalogo-cats" id="ct-cats"></div><div class="catalogo-corpo"><div class="catalogo-topo"><h2 id="ct-titulo"></h2><select id="ct-ordem"><option value="rec">Mais recentes</option><option value="az">A-Z</option><option value="nota">Melhor avaliados</option></select></div><div class="grade" id="ct-grade"></div></div></div>';
    var catsEl = $('ct-cats');
    catsEl.innerHTML = '<input class="busca" id="ct-busca" data-focusable tabindex="0" placeholder="Buscar ' + rotulo + '..." value="' + h(E.busca[tipo] || '') + '">' +
      '<button class="cat-btn ' + (sel === 'fav' ? 'ativo' : '') + '" data-cat="fav" data-focusable>\u2764\uFE0F FAVORITOS</button>' +
      '<button class="cat-btn ' + (sel === 'rec' ? 'ativo' : '') + '" data-cat="rec" data-focusable>\uD83C\uDF00 VISTO RECENTE</button>' +
      '<button class="cat-btn ' + (sel === '*' ? 'ativo' : '') + '" data-cat="*" data-focusable>' + rotuloTodos + '</button>' +
      cats.map(function (c) { return '<button class="cat-btn ' + (sel === c.id ? 'ativo' : '') + '" data-cat="' + h(c.id) + '" data-focusable>' + h(c.nomeLimpo) + '</button>'; }).join('');
    catsEl.querySelectorAll('[data-cat]').forEach(function (b) { b.addEventListener('click', function () { E.selecao[tipo] = b.getAttribute('data-cat'); E.busca[tipo] = ''; $('ct-busca').value = ''; catsEl.querySelectorAll('.cat-btn').forEach(function (x) { x.classList.toggle('ativo', x === b); }); renderGrade(tipo); }); });
    $('ct-busca').addEventListener('input', function () { E.busca[tipo] = this.value; renderGrade(tipo); });
    $('ct-ordem').value = E.ordem[tipo] || 'rec';
    $('ct-ordem').addEventListener('change', function () { E.ordem[tipo] = this.value; renderGrade(tipo); });
    renderGrade(tipo);
  }
  function renderGrade(tipo) {
    var sel = E.selecao[tipo], busca = E.busca[tipo], lista;
    if (busca) lista = buscarItens(tipo, busca);
    else if (sel === 'fav') lista = Store.favoritos()[tipo].map(function (id) { return porId(tipo, id); }).filter(Boolean);
    else if (sel === 'rec') lista = recentesTipo(tipo);
    else lista = itensDaCat(tipo, sel);
    var ordem = E.ordem[tipo] || 'rec';
    lista = lista.slice();
    if (ordem === 'az') lista.sort(function (a, b) { return a.nome.localeCompare(b.nome); });
    else if (ordem === 'nota') lista.sort(function (a, b) { return b.nota - a.nota; });
    else lista.sort(function (a, b) { return b.added - a.added; });
    $('ct-titulo').textContent = busca ? 'Resultado para "' + busca + '"' : (sel === 'fav' ? 'Favoritos' : (sel === 'rec' ? 'Visto recente' : (sel === '*' ? 'Todos' : nomeCat(tipo, sel)))) + ' (' + lista.length + ')';
    var g = $('ct-grade');
    g.innerHTML = lista.length ? lista.slice(0, 400).map(tipo === 'vod' ? cardVod : cardSerie).join('')
      : '<div class="vazio"><strong>Nada por aqui</strong>' + (sel === 'rec' ? 'O que você assistir vai aparecer aqui.' : (sel === 'fav' ? 'Toque em Favoritar em um título para guardá-lo aqui.' : 'Tente outra categoria ou a busca.')) + '</div>';
    ligarCards(g);
  }

  function telaFilme() {
    var it = porId('vod', E.params.id), v = $('view');
    if (!it) { v.innerHTML = '<div class="vazio">Filme não encontrado.</div>'; return; }
    v.innerHTML = '<div class="detalhe"><div class="detalhe-fundo" id="df-fundo"></div><div class="detalhe-grad"></div><div class="detalhe-conteudo"><div class="detalhe-capa"><img src="' + imgOuNada(it.capa) + '" alt=""></div><div class="detalhe-info"><button class="btn" id="df-voltar" data-focusable>&#8592; Voltar</button><h1>' + h(it.nome) + '</h1><div class="detalhe-meta" id="df-meta">' + (it.nota ? '<span><b>&#9733; ' + it.nota.toFixed(1) + '</b></span>' : '') + '<span>' + h(nomeCat('vod', it.cat)) + '</span></div><div class="detalhe-sinopse" id="df-sinopse">Carregando informações...</div><div id="df-extra"></div><div class="detalhe-botoes"><button class="btn btn-dourado" id="df-assistir" data-focusable>&#9654; Assistir</button><button class="btn" id="df-fav" data-focusable>' + (coracao(Store.ehFavorito('vod', it.id)) + (Store.ehFavorito('vod', it.id) ? ' Favorito' : ' Favoritar')) + '</button><button class="btn oculta" id="df-trailer" data-focusable>Trailer</button></div></div></div><div class="secao" id="df-semelhantes"></div></div>';
    $('df-voltar').onclick = voltar;
    var p = Store.lerProgresso('vod:' + it.id);
    if (p && p.dur && p.pos > 30 && p.pos < p.dur * 0.95) $('df-assistir').innerHTML = '&#9654; Continuar (' + Math.round(p.pos / p.dur * 100) + '%)';
    $('df-assistir').onclick = function () { tocarFilme(it); };
    $('df-fav').onclick = function () { var on = Store.alternarFavorito('vod', it.id); $('df-fav').innerHTML = coracao(on) + (on ? ' Favorito' : ' Favoritar'); };
    var semelhantes = itensDaCat('vod', it.cat).filter(function (x) { return x.id !== it.id; }).slice(0, 20);
    if (semelhantes.length) { $('df-semelhantes').innerHTML = '<h2>Filmes semelhantes</h2><div class="faixa">' + semelhantes.map(cardVod).join('') + '</div>'; ligarCards($('df-semelhantes')); }
    Api.vodInfo(E.cat, it.id).then(function (r) {
      if (!$('df-sinopse') || E.rota !== 'filme') return;
      var inf = (r && r.info) || {};
      $('df-sinopse').textContent = inf.plot || inf.description || 'Sem sinopse disponível.';
      var meta = [];
      if (inf.releasedate || inf.releaseDate) meta.push('<span>' + h(String(inf.releasedate || inf.releaseDate).slice(0, 10)) + '</span>');
      if (inf.genre) meta.push('<span>' + h(inf.genre) + '</span>');
      if (inf.duration) meta.push('<span>' + h(inf.duration) + '</span>');
      if (inf.rating) meta.push('<span><b>&#9733; ' + h(inf.rating) + '</b></span>');
      if (meta.length) $('df-meta').innerHTML = meta.join('');
      var ex = [];
      if (inf.cast) ex.push('<div class="detalhe-extra"><b>Elenco:</b> ' + h(inf.cast) + '</div>');
      if (inf.director) ex.push('<div class="detalhe-extra"><b>Direção:</b> ' + h(inf.director) + '</div>');
      $('df-extra').innerHTML = ex.join('');
      var fundo = (inf.backdrop_path && inf.backdrop_path[0]) || inf.movie_image || it.capa;
      if (fundo) $('df-fundo').style.backgroundImage = 'url("' + fundo + '")';
      if (inf.youtube_trailer) { var t = $('df-trailer'); t.classList.remove('oculta'); t.onclick = function () { window.open('https://www.youtube.com/watch?v=' + encodeURIComponent(inf.youtube_trailer), '_blank'); }; }
      if (r && r.movie_data && r.movie_data.container_extension) it.ext = r.movie_data.container_extension;
    });
  }
  // ---- player externo do Android (Exo Player e VLC), só existe dentro do APK ----
  function nativo() { return (typeof window !== 'undefined' && window.TelaVipNativo) ? window.TelaVipNativo : null; }
  function temExo() { var n = nativo(); return !!(n && n.abrirExo); }
  function temVlc() { var n = nativo(); try { return !!(n && n.temVlc && n.temVlc()); } catch (e) { return false; } }
  // chamado pelo Android quando o coração é usado na tela do Exo Player
  function favoritarDeFora(tipo, id) {
    if (!tipo || !id) return;
    var on = Store.alternarFavorito(tipo, String(id));
    toast(on ? 'Adicionado aos favoritos' : 'Removido dos favoritos');
    if (E.rota) ir(E.rota, E.params, true);
  }

  function abrirNoMotorExterno(url, titulo, favTipo, favId) {
    var n = nativo(), m = Store.config().motor;
    if (!n || !url || m === 'auto') return false;
    // escolheu VLC mas ele não está instalado: volta para o padrão em vez de falhar calado
    if (m === 'vlc' && !temVlc()) { Store.setConfig({ motor: 'auto' }); toast('O VLC não está instalado. Voltando para o player padrão.'); return false; }
    try {
      if (m === 'exo' && n.abrirExoCompleto && favTipo && favId) {
        return !!n.abrirExoCompleto(url, titulo || '', favTipo, String(favId), Store.ehFavorito(favTipo, favId));
      }
      if (m === 'exo' && n.abrirExo) return !!n.abrirExo(url, titulo || '');
      if (m === 'vlc' && n.abrirVlc) return !!n.abrirVlc(url, titulo || '');
    } catch (e) {}
    return false;
  }

  function tocarFilme(it) {
    revalidar(false);
    var chave = 'vod:' + it.id;
    var p = Store.lerProgresso(chave);

    function abrirComPos(posSeg) {
      if (playerNativoDisponivel()) {
        var fs = fontesVideoNativo(Api.urlsVod(E.cat, it)).map(function (u) { return { url: u, qualidade: '', formato: /\.m3u8(\?|$)/i.test(u) ? 'm3u8' : (/\.ts(\?|$)/i.test(u) ? 'ts' : '') }; });
        if (abrirPlayerNativo(fs, { titulo: it.nome, tipo: 'vod', id: it.id, favorito: Store.ehFavorito('vod', it.id), aoVivo: false, capa: it.capa || '', sub: nomeCat('vod', it.cat), posMs: posSeg > 0 ? Math.round(posSeg * 1000) : 0 })) return;
      }
      Player.abrir({ tipo: 'vod', id: it.id, titulo: it.nome, sub: nomeCat('vod', it.cat), capa: it.capa, url: Api.urlVod(E.cat, it), urls: Api.urlsVod(E.cat, it),
        ehFavorito: function () { return Store.ehFavorito('vod', it.id); }, aoFavoritar: function () { return Store.alternarFavorito('vod', it.id); },
        aoInfo: function () { Player.fechar(); ir('filme', { id: it.id }); }
      }, function () { if (E.rota === 'filme' || E.rota === 'inicio') ir(E.rota, E.params, true); });
    }

    var podeRetomar = p && p.pos > 30 && (!p.dur || p.pos < p.dur * 0.9);
    if (podeRetomar) {
      escolherRetomada(p).then(function (continuar) {
        if (!continuar) Store.removerProgresso(chave);
        abrirComPos(continuar ? p.pos : 0);
      });
      return;
    }
    abrirComPos(0);
  }

  function telaSerie() {
    var it = porId('series', E.params.id), v = $('view');
    if (!it) { v.innerHTML = '<div class="vazio">Série não encontrada.</div>'; return; }
    v.innerHTML = '<div class="detalhe"><div class="detalhe-fundo" id="ds-fundo"></div><div class="detalhe-grad"></div><div class="detalhe-conteudo"><div class="detalhe-capa"><img src="' + imgOuNada(it.capa) + '" alt=""></div><div class="detalhe-info"><button class="btn" id="ds-voltar" data-focusable>&#8592; Voltar</button><h1>' + h(it.nome) + '</h1><div class="detalhe-meta" id="ds-meta">' + (it.ano ? '<span>' + h(it.ano) + '</span>' : '') + (it.genero ? '<span>' + h(it.genero) + '</span>' : '') + (it.nota ? '<span><b>&#9733; ' + it.nota.toFixed(1) + '</b></span>' : '') + '</div><div class="detalhe-sinopse">' + h(it.sinopse || 'Carregando...') + '</div><div class="detalhe-botoes"><button class="btn btn-dourado" id="ds-assistir" data-focusable>&#9654; Assistir</button><button class="btn" id="ds-fav" data-focusable>' + (coracao(Store.ehFavorito('series', it.id)) + (Store.ehFavorito('series', it.id) ? ' Favorito' : ' Favoritar')) + '</button></div></div></div><div class="temporadas" id="ds-temps"></div><div class="episodios" id="ds-eps"><div class="vazio">Carregando episódios...</div></div></div>';
    $('ds-voltar').onclick = voltar;
    $('ds-fav').onclick = function () { var on = Store.alternarFavorito('series', it.id); $('ds-fav').innerHTML = coracao(on) + (on ? ' Favorito' : ' Favoritar'); };
    if (it.fundo) $('ds-fundo').style.backgroundImage = 'url("' + it.fundo + '")'; else if (it.capa) $('ds-fundo').style.backgroundImage = 'url("' + it.capa + '")';
    Api.seriesInfo(E.cat, it).then(function (r) {
      if (E.rota !== 'serie' || !$('ds-temps')) return;
      var temps = Object.keys(r.temporadas).sort(function (a, b) { return +a - +b; });
      if (r.info && r.info.plot) v.querySelector('.detalhe-sinopse').textContent = r.info.plot;
      if (!temps.length) { $('ds-eps').innerHTML = '<div class="vazio">Nenhum episódio disponível.</div>'; return; }
      var tAtual = E.params.temporada && temps.indexOf(String(E.params.temporada)) !== -1 ? String(E.params.temporada) : temps[0];
      function renderTemp(t) {
        $('ds-temps').innerHTML = temps.map(function (x) { return '<button class="' + (x === t ? 'ativo' : '') + '" data-t="' + h(x) + '" data-focusable>Temporada ' + h(x) + '</button>'; }).join('');
        $('ds-temps').querySelectorAll('[data-t]').forEach(function (b) { b.addEventListener('click', function () { renderTemp(b.getAttribute('data-t')); }); });
        var eps = r.temporadas[t].slice().sort(function (a, b) { return a.num - b.num; }), vistos = Store.episodiosVistos();
        $('ds-eps').innerHTML = eps.map(function (e) { var p = Store.lerProgresso('ep:' + e.id); return '<button class="episodio" data-ep="' + h(e.id) + '" data-focusable><img ' + imgAdiada(e.capa || it.capa) + ' alt=""><span class="ep-num">E' + String(e.num).padStart(2, '0') + '</span>' + (e.duracao ? '<span class="ep-dur">' + h(e.duracao) + '</span>' : '') + '<span class="ep-nome">' + h(e.titulo) + '</span>' + (vistos[e.id] ? '<span class="visto">&#10003; visto</span>' : (p && p.dur ? '<span class="visto" style="color:#e3b341">' + Math.round(p.pos / p.dur * 100) + '%</span>' : '')) + '</button>'; }).join('');
        $('ds-eps').querySelectorAll('[data-ep]').forEach(function (b) { b.addEventListener('click', function () { var e = eps.find(function (x) { return x.id === b.getAttribute('data-ep'); }); tocarEpisodio(it, e, eps, t); }); });
        $('ds-assistir').onclick = function () {
          // próximo não visto, ou o último que estava vendo
          var prog = Store.progresso(), vist = Store.episodiosVistos();
          var emAndamento = eps.find(function (e) { var p = prog['ep:' + e.id]; return p && p.dur && p.pos < p.dur * 0.95; });
          var prox = emAndamento || eps.find(function (e) { return !vist[e.id]; }) || eps[0];
          tocarEpisodio(it, prox, eps, t);
        };
        if (E.params.epId) { var alvo = eps.find(function (e) { return e.id === E.params.epId; }); E.params.epId = null; if (alvo) tocarEpisodio(it, alvo, eps, t); }
      }
      renderTemp(tAtual);
    });
  }
  function tocarEpisodio(serie, ep, eps, temporada) {
    var idx = eps.findIndex(function (x) { return x.id === ep.id; });
    revalidar(false);
    var chave = 'ep:' + ep.id;
    var pp = Store.lerProgresso(chave);

    function abrirComPos(posSeg) {
      if (playerNativoDisponivel()) {
        var efs = fontesVideoNativo(Api.urlsEpisodio(E.cat, ep)).map(function (u) { return { url: u, qualidade: '', formato: /\.m3u8(\?|$)/i.test(u) ? 'm3u8' : (/\.ts(\?|$)/i.test(u) ? 'ts' : '') }; });
        if (abrirPlayerNativo(efs, { titulo: serie.nome, tipo: 'ep', id: ep.id, favorito: Store.ehFavorito('series', serie.id), favoritoTipo: 'series', favoritoId: serie.id, aoVivo: false, capa: ep.capa || serie.capa || '', sub: 'T' + temporada + ' E' + ep.num + ' · ' + ep.titulo, ref: { serieId: serie.id, temporada: temporada }, posMs: posSeg > 0 ? Math.round(posSeg * 1000) : 0 })) return;
      }
      Player.abrir({
        tipo: 'ep', id: ep.id, titulo: serie.nome, sub: 'T' + temporada + ' E' + ep.num + ' · ' + ep.titulo, capa: ep.capa || serie.capa, url: Api.urlEpisodio(E.cat, ep), urls: Api.urlsEpisodio(E.cat, ep),
        lista: eps, indice: idx, ref: { serieId: serie.id, temporada: temporada },
        ehFavorito: function () { return Store.ehFavorito('series', serie.id); }, aoFavoritar: function () { return Store.alternarFavorito('series', serie.id); },
        aoInfo: function () { Player.fechar(); ir('serie', { id: serie.id, temporada: temporada }); },
        aoNavegar: function (prox) { Store.marcarVisto(ep.id); tocarEpisodio(serie, prox, eps, temporada); }
      }, function () { if (E.rota === 'serie') ir('serie', { id: serie.id, temporada: temporada }, true); });
    }

    var podeRetomar = pp && pp.pos > 30 && (!pp.dur || pp.pos < pp.dur * 0.9);
    if (podeRetomar) {
      escolherRetomada(pp).then(function (continuar) {
        if (!continuar) Store.removerProgresso(chave);
        abrirComPos(continuar ? pp.pos : 0);
      });
      return;
    }
    abrirComPos(0);
  }

  // ============ INFANTIL ============
  function telaInfantil() {
    var v = $('view'), html = '';
    var cl = catsVisiveis('live').filter(function (c) { return ehInfantil(c.nome); }), cv = catsVisiveis('vod').filter(function (c) { return ehInfantil(c.nome); }), cs = catsVisiveis('series').filter(function (c) { return ehInfantil(c.nome); });
    var canais = [].concat.apply([], cl.map(function (c) { return itensDaCat('live', c.id); })), filmes = [].concat.apply([], cv.map(function (c) { return itensDaCat('vod', c.id); })), series = [].concat.apply([], cs.map(function (c) { return itensDaCat('series', c.id); }));
    if (!canais.length && !filmes.length && !series.length) { v.innerHTML = '<div class="infantil"><div class="vazio"><strong>Nada infantil encontrado</strong>Esta lista não tem categorias com nomes infantis. As palavras usadas podem ser ajustadas no painel.</div></div>'; return; }
    var busca = (E.busca.infantil || '').toLowerCase().trim();
    if (busca) { var f = function (x) { return x.nome.toLowerCase().indexOf(busca) !== -1; }; canais = canais.filter(f); filmes = filmes.filter(f); series = series.filter(f); }
    html = '<div class="infantil">' + html + '<div class="secao"><input class="busca" id="inf-busca" data-focusable tabindex="0" placeholder="Buscar no infantil..." value="' + h(E.busca.infantil || '') + '" style="max-width:420px"></div>';
    if (busca && !canais.length && !filmes.length && !series.length) html += '<div class="vazio">Nada encontrado para "' + h(busca) + '".</div>';
    if (canais.length) html += '<div class="secao"><h2>Canais infantis</h2><div class="faixa">' + canais.slice(0, 40).map(cardCanal).join('') + '</div></div>';
    if (filmes.length) html += '<div class="secao"><h2>Filmes infantis <small>' + filmes.length + '</small></h2></div><div class="grade">' + filmes.slice().sort(function (a, b) { return b.added - a.added; }).slice(0, 120).map(cardVod).join('') + '</div>';
    if (series.length) html += '<div class="secao"><h2>Séries e desenhos <small>' + series.length + '</small></h2></div><div class="grade">' + series.slice().sort(function (a, b) { return b.added - a.added; }).slice(0, 120).map(cardSerie).join('') + '</div>';
    v.innerHTML = html + '</div>'; ligarCards(v);
    var inp = $('inf-busca');
    inp.addEventListener('input', function () { E.busca.infantil = this.value; var pos = this.selectionStart; telaInfantil(); var n = $('inf-busca'); n.focus(); try { n.setSelectionRange(pos, pos); } catch (e) {} });
  }

  // ============ PERFIL / LISTAS ============
  function telaPerfil() {
    var v = $('view'), lib = E.lib || {}, ap = Store.aparelho(), fav = Store.favoritos(), prog = Store.progresso();
    var html = '<div class="config-corpo"><h1>Perfil</h1><div class="bloco"><h3>' + h(lib.nome || 'Cliente') + (lib.tipo_conta === 'TESTE' ? ' <small style="color:#aaa;font-weight:600">(TESTE)</small>' : '') + '</h3><p>' + (lib.validade ? 'Válido até <b style="color:#e3b341">' + h(lib.validade) + '</b> (' + lib.dias_restantes + ' dias)' : '') + '</p><p>Código do aparelho: <b style="color:#e3b341">' + h(ap.codigo) + '</b> · Chave: <b style="color:#e3b341">' + h(ap.chave) + '</b></p><div class="linha-acoes"><button class="btn" id="pf-copiar" data-focusable>Copiar código</button>' + (lib.config && lib.config.whatsapp ? '<button class="btn btn-vermelho" id="pf-whats" data-focusable>Suporte no WhatsApp</button>' : '') + '</div></div>';
    html += '<div class="bloco"><h3>Favoritos</h3><p>' + fav.live.length + ' canais · ' + fav.vod.length + ' filmes · ' + fav.series.length + ' séries</p></div>';
    html += '<div class="bloco"><h3>Histórico</h3><p>' + Object.keys(prog).length + ' itens em andamento · ' + Store.canaisRecentes().length + ' canais recentes</p><div class="linha-acoes"><button class="btn" id="pf-limpar-hist" data-focusable>Limpar histórico</button></div></div></div>';
    v.innerHTML = html;
    $('pf-copiar').onclick = function () { copiar('Código: ' + ap.codigo + '\nChave: ' + ap.chave); };
    if ($('pf-whats')) $('pf-whats').onclick = function () { window.open(lib.config.whatsapp, '_blank'); };
    $('pf-limpar-hist').onclick = function () { confirmar('Limpar histórico', 'Apaga o "continuar assistindo" e os canais recentes. Os favoritos ficam.').then(function (ok) { if (ok) { Store.limparProgresso(); localStorage.removeItem('telavip_canais_recentes'); localStorage.removeItem('telavip_vistos'); toast('Histórico limpo'); telaPerfil(); } }); };
  }
  function telaListas() {
    var v = $('view'), listas = (E.lib && E.lib.listas) || [], cfg = Store.config();
    v.innerHTML = '<div class="config-corpo"><h1>Trocar lista</h1><div class="bloco"><p>Listas liberadas para este aparelho pelo suporte. Toque para trocar.</p><div class="lista-simples" id="ls-lista">' + listas.map(function (l, i) { var c = Api.analisarLink(l.link); return '<button class="' + (i === (cfg.listaAtiva || 0) ? 'ativo' : '') + '" data-i="' + i + '" data-focusable><b>' + h(l.nome) + '</b><small>' + (c.tipo === 'xtream' ? c.base.replace(/^https?:\/\//, '') : 'M3U') + '</small>' + (i === (cfg.listaAtiva || 0) ? '<small class="em-uso">EM USO</small>' : '') + '</button>'; }).join('') + '</div><div class="linha-acoes"><button class="btn" id="ls-atualizar" data-focusable>Atualizar conteúdo da lista atual</button><button class="btn" id="ls-painel" data-focusable>Verificar novas listas no painel</button></div></div></div>';
    v.querySelectorAll('[data-i]').forEach(function (b) { b.addEventListener('click', function () { Store.setConfig({ listaAtiva: +b.getAttribute('data-i') }); mostrarTela('carregando'); carregarCatalogo(); }); });
    $('ls-atualizar').onclick = function () { mostrarTela('carregando'); carregarCatalogo(); };
    $('ls-painel').onclick = function () {
      toast('Consultando o painel...');
      verificarAtivacao(true, true).then(function (r) {
        if (!r) { toast('Sem conexão com o painel'); return; }
        if (!r.ok) return;
        if (!r.listas || !r.listas.length) return;
        telaListas();
        toast('Atualizado');
      });
    };
  }

  // ============ CONFIGURAÇÕES ============
  var CFG_MENU = [
    { id: 'atalho_atualizar', nome: '\u267B\uFE0F ATUALIZAR APP', sub: function () { return 'Procurar versão nova das telas'; } },
    { id: 'atalho_adulto', nome: '\u2622\uFE0F ATIVAR ADULTO', sub: function () { return E.adultoLiberado ? 'Liberado nesta sessão' : 'Categorias escondidas'; } },
    { id: 'lista', nome: '\u2705 LISTAS', sub: function () { return 'Lista e conteúdo'; } },
    { id: 'player', nome: '\uD83C\uDFA5 PLAYER', sub: function (c) { return (c.qualidade === 'lista' ? 'Como está na lista' : c.qualidade.toUpperCase()) + ' · Player integrado'; } },
    { id: 'dispositivo', nome: '\uD83D\uDCFA DISPOSITIVO', sub: function (c) { return c.dispositivo === 'auto' ? 'Automático' : (c.dispositivo === 'tv' ? 'TV' : 'Mobile'); } },
    { id: 'idioma', nome: '\u2734\uFE0F IDIOMA', sub: function () { return 'Português'; } },
    { id: 'adulto', nome: '\uD83D\uDD1E ADULTO', sub: function (c) { return c.pinAtivo ? 'PIN ativo' : 'Sem PIN'; } },
    { id: 'rede', nome: '\uD83D\uDCE1 REDE', sub: function () { return 'Teste de velocidade'; } },
    { id: 'historico', nome: '\uD83C\uDF00 HISTÓRICO', sub: function () { return Object.keys(Store.progresso()).length + ' em andamento'; } },
    { id: 'sair', nome: '\u27A1\uFE0F SAIR', sub: function () { return ''; } }
  ];

  function atalhoAdulto() {
    var cfg = Store.config();
    if (E.adultoLiberado) { E.adultoLiberado = false; E.selecao = {}; toast('Categorias adultas escondidas'); telaConfig(null); return; }
    if (cfg.pinAtivo) {
      pedirPin('PIN', 'Digite o PIN para liberar as categorias adultas.').then(function (v) {
        if (v === cfg.pin) { E.adultoLiberado = true; E.selecao = {}; toast('Liberado nesta sessão'); telaConfig(null); }
        else if (v !== null) toast('PIN incorreto');
      });
      return;
    }
    confirmar('Ativar adulto', 'As categorias adultas vão aparecer nas listas. Crie um PIN em ADULTO se quiser proteger.', 'Ativar').then(function (ok) {
      if (ok) { E.adultoLiberado = true; E.selecao = {}; toast('Categorias adultas liberadas'); telaConfig(null); }
    });
  }
  function atalhoAtualizar() {
    if (window.TelaVipNativo && window.TelaVipNativo.buscarAtualizacao) { window.TelaVipNativo.buscarAtualizacao(); return; }
    toast('Procurando atualização...');
    verificarAtualizacao();
    setTimeout(function () { toast('Você já está na versão mais recente'); }, 2500);
  }

  function telaConfig(secao) {
    var v = $('view'), cfg = Store.config(), lib = E.lib || {}, ap = Store.aparelho();
    var mobile = window.innerWidth <= 860;
    secao = secao || (mobile ? null : 'lista');
    v.innerHTML = '<div class="config ' + (secao ? 'aberto' : '') + '"><div class="config-menu" id="cf-menu">' + (mobile ? '' : '<button class="btn" id="cf-voltar" data-focusable style="margin-bottom:.8em">&#8592; Voltar</button>') + CFG_MENU.map(function (m) { return '<button class="' + (m.id === secao ? 'ativo' : '') + '" data-sec="' + m.id + '" data-focusable><strong>' + m.nome + '</strong><small>' + h(m.sub(cfg)) + '</small></button>'; }).join('') + '<div class="config-rodape">' + h(CFG.APP_NAME) + ' v<span data-versao>' + h(VERSAO_TELAS) + '</span> · ' + Api.tipoAparelho() + '<br>Código <b>' + h(ap.codigo) + '</b> · Chave <b>' + h(ap.chave) + '</b>' + (lib.validade ? '<br>Válido até <b>' + h(lib.validade) + '</b>' : '') + '</div></div><div class="config-corpo" id="cf-corpo"></div></div>';
    if ($('cf-voltar')) $('cf-voltar').onclick = voltar;
    v.querySelectorAll('[data-sec]').forEach(function (b) { b.addEventListener('click', function () {
      var s = b.getAttribute('data-sec');
      if (s === 'sair') { sair(); return; }
      if (s === 'atalho_atualizar') { atalhoAtualizar(); return; }
      if (s === 'atalho_adulto') { atalhoAdulto(); return; }
      telaConfig(s);
    }); });
    if (secao) renderConfigSecao(secao);
  }
  function opcoes(id, lista, atual, aoMudar) {
    var html = '<div class="opcoes" id="' + id + '">' + lista.map(function (o) { return '<button class="' + (o.v === atual ? 'ativo' : '') + '" data-v="' + h(o.v) + '" data-focusable' + (o.off ? ' disabled' : '') + '>' + h(o.n) + '</button>'; }).join('') + '</div>';
    setTimeout(function () { var el = $(id); if (!el) return; el.querySelectorAll('[data-v]').forEach(function (b) { b.addEventListener('click', function () { el.querySelectorAll('button').forEach(function (x) { x.classList.toggle('ativo', x === b); }); aoMudar(b.getAttribute('data-v')); }); }); }, 0);
    return html;
  }
  function renderConfigSecao(s) {
    var c = $('cf-corpo'), cfg = Store.config(), html = '', mobile = window.innerWidth <= 860;
    var topo = mobile ? '<button class="btn" id="cf-fechar" data-focusable style="margin-bottom:.8em">&#8592; Menu</button>' : '';
    if (s === 'lista') {
      html = topo + '<h1>Lista</h1><div class="bloco"><h3>Reprodução automática</h3><p>O aplicativo escolhe sozinho a melhor forma de abrir cada canal. Não é necessário alterar formato ou protocolo.</p></div>';
      html += '<div class="bloco"><h3>Lista em uso</h3><p>' + h((listaAtual() || {}).nome || '') + '</p><div class="linha-acoes"><button class="btn" id="cf-trocar" data-focusable>Trocar lista</button><button class="btn" id="cf-atualizar" data-focusable>Atualizar conteúdo</button></div></div>';
      html += '<div class="bloco"><h3>Ocultar categorias</h3><p>Esconda categorias que você não usa. Elas somem das telas, mas continuam na lista.</p><div class="linha-acoes"><button class="btn" data-oc="live" data-focusable>Canais</button><button class="btn" data-oc="vod" data-focusable>Filmes</button><button class="btn" data-oc="series" data-focusable>Séries</button></div></div>';
    } else if (s === 'player') {
      html = topo + '<h1>Player</h1><div class="bloco"><h3>Player integrado</h3><p>No aplicativo Android, a reprodução usa o motor VLC integrado automaticamente. Não é necessário instalar outro player nem escolher entre motores.</p></div>';
      html += '<div class="bloco"><h3>Qualidade ao abrir um canal</h3><p>Quando o canal existe em várias qualidades (Padrão, SD, HD, FHD), o app abre nesta. HD é o equilíbrio entre imagem boa e pouca travada. Dá para trocar para FHD ou SD no próprio player.</p>' + opcoes('op-qual', [{ v: 'hd', n: 'HD (recomendado)' }, { v: 'fhd', n: 'FHD' }, { v: 'sd', n: 'Padrão / SD' }, { v: 'lista', n: 'Como está na lista' }], cfg.qualidade, function (v) { Store.setConfig({ qualidade: v }); }) + '</div>';
      html += '<div class="bloco"><h3>Pular intro</h3><p>Quanto o botão "pular" avança em séries.</p>' + opcoes('op-intro', [{ v: '0', n: 'Desativado' }, { v: '30', n: '30s' }, { v: '45', n: '45s' }, { v: '60', n: '60s' }, { v: '90', n: '90s' }], String(cfg.pularIntro), function (v) { Store.setConfig({ pularIntro: +v }); }) + '</div>';
      html += '<div class="bloco"><h3>Buffer</h3><p>"Alto" guarda mais vídeo antes de tocar. Ajuda em internet fraca, mas demora mais para começar e para trocar de canal.</p>' + opcoes('op-buf', [{ v: 'normal', n: 'Normal' }, { v: 'alto', n: 'Alto (internet fraca)' }], cfg.buffer, function (v) { Store.setConfig({ buffer: v }); }) + '</div>';
    } else if (s === 'dispositivo') {
      html = topo + '<h1>Dispositivo</h1><div class="bloco"><h3>Tipo de aparelho</h3><p>TV deixa tudo maior e prepara para controle remoto. Mobile é para toque.</p>' + opcoes('op-disp', [{ v: 'auto', n: 'Automático' }, { v: 'tv', n: 'TV' }, { v: 'mobile', n: 'Mobile' }], cfg.dispositivo, function (v) { Store.setConfig({ dispositivo: v }); aplicarModoDispositivo(); }) + '</div>';
      html += '<div class="bloco"><h3>Ajuste de tela</h3><p>Como o vídeo preenche a tela.</p>' + opcoes('op-aj', [{ v: 'ajustar', n: 'Ajustar' }, { v: 'esticar', n: 'Esticar' }, { v: 'zoom', n: 'Zoom' }], cfg.ajusteTela, function (v) { Store.setConfig({ ajusteTela: v }); }) + '</div>';
      html += '<div class="bloco"><h3>Atualização do app</h3><p id="at-info">Versão do app: <b>' + h((window.TelaVipNativo && window.TelaVipNativo.versaoApk) ? window.TelaVipNativo.versaoApk() : TELAVIP_BUILD) + '</b> · Telas: <span data-versao>' + h(VERSAO_TELAS) + '</span></p><div class="linha-acoes"><button class="btn btn-dourado" id="cf-atualizar-app" data-focusable>Buscar atualização</button></div></div>';
      var ap = Store.aparelho();
      html += '<div class="bloco"><h3>Identificação</h3><p>Código <b style="color:#e3b341">' + h(ap.codigo) + '</b> · Chave <b style="color:#e3b341">' + h(ap.chave) + '</b></p><div class="linha-acoes"><button class="btn" id="cf-copiar" data-focusable>Copiar</button></div></div>';
    } else if (s === 'idioma') {
      html = topo + '<h1>Idioma</h1><div class="bloco"><h3>Idioma do app</h3><p>Inglês e espanhol chegam em uma próxima versão.</p>' + opcoes('op-idi', [{ v: 'pt', n: 'Português' }, { v: 'en', n: 'English', off: true }, { v: 'es', n: 'Español', off: true }], cfg.idioma, function () {}) + '</div>';
    } else if (s === 'adulto') {
      html = topo + '<h1>Adulto</h1><div class="bloco"><h3>Controle dos pais</h3><p>Categorias adultas ficam escondidas. Com PIN ativo, só aparecem depois de digitar o PIN nesta tela.</p><div class="linha-acoes"><button class="btn ' + (cfg.pinAtivo ? '' : 'btn-dourado') + '" id="cf-pin" data-focusable>' + (cfg.pinAtivo ? 'Trocar PIN' : 'Criar PIN') + '</button>' + (cfg.pinAtivo ? '<button class="btn" id="cf-pin-off" data-focusable>Desativar PIN</button>' : '') + '</div></div>';
      html += '<div class="bloco"><h3>Categorias adultas</h3><p>' + (E.adultoLiberado ? 'Liberadas nesta sessão.' : 'Escondidas.') + '</p><div class="linha-acoes"><button class="btn" id="cf-adulto" data-focusable>' + (E.adultoLiberado ? 'Esconder de novo' : 'Mostrar categorias adultas') + '</button></div></div>';
    } else if (s === 'rede') {
      html = topo + '<h1>Rede</h1><div class="bloco"><h3>Teste de velocidade</h3><p>Mede a velocidade entre este aparelho e o servidor da sua lista, que é o que importa para o vídeo.</p><div class="velocidade-res" id="vel-res">--</div><p id="vel-msg"></p><div class="linha-acoes"><button class="btn btn-dourado" id="cf-teste" data-focusable>Iniciar teste</button></div></div>';
    } else if (s === 'historico') {
      var prog = Store.progresso(), n = Object.keys(prog).length;
      html = topo + '<h1>Histórico</h1><div class="bloco"><h3>Em andamento</h3><p>' + n + ' filmes e episódios com progresso salvo.</p><div class="linha-acoes"><button class="btn" id="cf-lf" data-focusable>Limpar filmes</button><button class="btn" id="cf-ls" data-focusable>Limpar séries</button><button class="btn btn-vermelho" id="cf-lt" data-focusable>Limpar tudo</button></div></div>';
      html += '<div class="bloco"><h3>Dados do app</h3><p>Apaga favoritos, histórico e configurações deste aparelho. O código do aparelho é mantido.</p><div class="linha-acoes"><button class="btn btn-vermelho" id="cf-reset" data-focusable>Limpar dados do app</button></div></div>';
    }
    c.innerHTML = html;
    if ($('cf-fechar')) $('cf-fechar').onclick = function () { telaConfig(null); };
    if ($('cf-trocar')) $('cf-trocar').onclick = function () { ir('listas'); };
    if ($('cf-atualizar')) $('cf-atualizar').onclick = function () { mostrarTela('carregando'); carregarCatalogo(); };
    c.querySelectorAll('[data-oc]').forEach(function (b) { b.addEventListener('click', function () { dialogoOcultar(b.getAttribute('data-oc')); }); });
    if ($('cf-copiar')) $('cf-copiar').onclick = function () { var ap = Store.aparelho(); copiar('Código: ' + ap.codigo + '\nChave: ' + ap.chave); };
    if ($('cf-atualizar-app')) {
      var temNativo = !!(window.TelaVipNativo && window.TelaVipNativo.buscarAtualizacao);
      if (temNativo && window.TelaVipNativo.versaoTelas) {
        try { var va = window.TelaVipNativo.versaoApk ? window.TelaVipNativo.versaoApk() : TELAVIP_BUILD; $('at-info').textContent = 'Versão do app: ' + va + ' · Telas: ' + window.TelaVipNativo.versaoTelas(); } catch (e) {}
      }
      $('cf-atualizar-app').onclick = function () {
        if (temNativo) { window.TelaVipNativo.buscarAtualizacao(); return; }
        toast('Procurando atualização...');
        verificarAtualizacao();
        setTimeout(function () { toast('Você já está na versão mais recente'); }, 2500);
      };
    }
    if ($('cf-pin')) $('cf-pin').onclick = function () {
      (cfg.pinAtivo ? pedirPin('PIN atual', 'Digite o PIN atual para trocar.') : Promise.resolve('')).then(function (v) {
        if (cfg.pinAtivo && v !== cfg.pin) { if (v !== null) toast('PIN incorreto'); return; }
        pedirPin('Novo PIN', 'Digite um PIN de 4 a 6 números.').then(function (novo) { if (!novo) return; if (!/^\d{4,6}$/.test(novo)) { toast('Use de 4 a 6 números'); return; } Store.setConfig({ pin: novo, pinAtivo: true }); E.adultoLiberado = false; toast('PIN salvo'); telaConfig('adulto'); });
      });
    };
    if ($('cf-pin-off')) $('cf-pin-off').onclick = function () { pedirPin('Desativar PIN', 'Digite o PIN atual.').then(function (v) { if (v === cfg.pin) { Store.setConfig({ pin: '', pinAtivo: false }); toast('PIN desativado'); telaConfig('adulto'); } else if (v !== null) toast('PIN incorreto'); }); };
    if ($('cf-adulto')) $('cf-adulto').onclick = function () {
      if (E.adultoLiberado) { E.adultoLiberado = false; telaConfig('adulto'); return; }
      if (cfg.pinAtivo) pedirPin('PIN', 'Digite o PIN para mostrar as categorias adultas.').then(function (v) { if (v === cfg.pin) { E.adultoLiberado = true; toast('Liberado nesta sessão'); telaConfig('adulto'); } else if (v !== null) toast('PIN incorreto'); });
      else confirmar('Mostrar categorias adultas', 'Sem PIN, qualquer pessoa pode fazer isso. Crie um PIN se quiser proteger.', 'Mostrar').then(function (ok) { if (ok) { E.adultoLiberado = true; telaConfig('adulto'); } });
    };
    if ($('cf-teste')) $('cf-teste').onclick = testeVelocidade;
    if ($('cf-lf')) $('cf-lf').onclick = function () { Store.limparProgresso('vod:'); toast('Histórico de filmes limpo'); telaConfig('historico'); };
    if ($('cf-ls')) $('cf-ls').onclick = function () { Store.limparProgresso('ep:'); localStorage.removeItem('telavip_vistos'); toast('Histórico de séries limpo'); telaConfig('historico'); };
    if ($('cf-lt')) $('cf-lt').onclick = function () { Store.limparProgresso(); localStorage.removeItem('telavip_vistos'); localStorage.removeItem('telavip_canais_recentes'); toast('Histórico limpo'); telaConfig('historico'); };
    if ($('cf-reset')) $('cf-reset').onclick = function () { confirmar('Limpar dados do app', 'Apaga favoritos, histórico e configurações. Você continua liberado no painel.', 'Limpar').then(function (ok) { if (ok) { var lib = Store.liberacao(); Store.limparTudo(); Store.setLiberacao(lib); toast('Dados limpos'); mostrarTela('carregando'); carregarCatalogo(); } }); };
  }
  function dialogoOcultar(tipo) {
    var cfg = Store.config(), oc = (cfg.catsOcultas && cfg.catsOcultas[tipo]) || [];
    var cats = E.cat[tipo].cats.filter(function (c) { return E.adultoLiberado || !ehAdulto(c.nome); });
    dialogo('<h3>Ocultar categorias</h3><p>Marcadas = escondidas.</p><div class="lista-simples" style="max-height:50vh;overflow:auto">' + cats.map(function (c) { return '<button data-c="' + h(c.id) + '" class="' + (oc.indexOf(c.id) !== -1 ? 'ativo' : '') + '" data-focusable><b>' + h(c.nomeLimpo) + '</b><small>' + (oc.indexOf(c.id) !== -1 ? 'oculta' : '') + '</small></button>'; }).join('') + '</div><div class="dialogo-botoes"><button class="btn btn-dourado" id="dg-ok" data-focusable>Pronto</button></div>', function (cx) {
      cx.querySelectorAll('[data-c]').forEach(function (b) { b.addEventListener('click', function () { var id = b.getAttribute('data-c'), i = oc.indexOf(id); if (i === -1) oc.push(id); else oc.splice(i, 1); b.classList.toggle('ativo', i === -1); b.querySelector('small').textContent = i === -1 ? 'oculta' : ''; }); });
      $('dg-ok').onclick = function () { var co = cfg.catsOcultas || { live: [], vod: [], series: [] }; co[tipo] = oc; Store.setConfig({ catsOcultas: co }); fecharDialogo(); E.selecao = {}; toast('Salvo'); };
    });
  }
  function testeVelocidade() {
    var res = $('vel-res'), m = $('vel-msg'), btn = $('cf-teste');
    btn.disabled = true; res.textContent = '...'; m.innerHTML = 'Medindo o ping...';
    var down = 0, up = 0, ping = 0;
    function medirPing() {
      var t0 = performance.now();
      return fetch('https://speed.cloudflare.com/__down?bytes=0&_=' + Date.now(), { cache: 'no-store' }).then(function () { ping = Math.round(performance.now() - t0); }).catch(function () { ping = 0; });
    }
    function medirDownload() {
      m.innerHTML = 'Medindo download (até 8s)...';
      var ctrl = window.AbortController ? new AbortController() : null, bytes = 0, t0 = performance.now(), fimT;
      return new Promise(function (resolve) {
        var terminar = function () { var seg = (performance.now() - t0) / 1000; down = seg > 0.3 ? bytes * 8 / seg / 1e6 : 0; resolve(); };
        fimT = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
        fetch('https://speed.cloudflare.com/__down?bytes=50000000&_=' + Date.now(), Object.assign({ cache: 'no-store' }, ctrl ? { signal: ctrl.signal } : {})).then(function (r) {
          var rd = r.body.getReader();
          return rd.read().then(function passo(x) { if (x.done) return; bytes += x.value.length; res.textContent = (bytes * 8 / ((performance.now() - t0) / 1000) / 1e6).toFixed(1) + ' Mbps'; return rd.read().then(passo); });
        }).then(function () { clearTimeout(fimT); terminar(); }).catch(function () { clearTimeout(fimT); terminar(); });
      });
    }
    function medirUpload() {
      m.innerHTML = 'Medindo upload...';
      var tam = 4 * 1024 * 1024, dados = new Uint8Array(tam), t0 = performance.now();
      return fetch('https://speed.cloudflare.com/__up?_=' + Date.now(), { method: 'POST', body: dados, cache: 'no-store' }).then(function () { var seg = (performance.now() - t0) / 1000; up = seg > 0 ? tam * 8 / seg / 1e6 : 0; }).catch(function () { up = 0; });
    }
    medirPing().then(medirDownload).then(medirUpload).then(function () {
      res.textContent = down ? down.toFixed(1) + ' Mbps' : 'Falhou';
      var dica = !down ? 'Não consegui medir. Verifique a conexão.' : (down < 4 ? 'Fraca: prefira canais SD e ative o buffer alto.' : down < 10 ? 'Razoável: HD deve funcionar, 4K pode travar.' : down < 25 ? 'Boa: suficiente para Full HD.' : 'Ótima: suficiente para 4K.');
      m.innerHTML = '<b>Download:</b> ' + (down ? down.toFixed(1) + ' Mbps' : '--') + ' · <b>Upload:</b> ' + (up ? up.toFixed(1) + ' Mbps' : '--') + ' · <b>Ping:</b> ' + (ping ? ping + ' ms' : '--') + '<br>' + dica;
      btn.disabled = false;
    });
  }

  // ============ modo TV / teclado ============
  function aplicarModoDispositivo() {
    var cfg = Store.config(), tv;
    if (cfg.dispositivo === 'tv') tv = true; else if (cfg.dispositivo === 'mobile') tv = false;
    else tv = /\b(TV|SmartTV|AFT|BRAVIA|Roku|Tizen|Web0S|WebOS|MiBOX|SHIELD)\b/i.test(navigator.userAgent) || (!('ontouchstart' in window) && window.innerWidth >= 1200 && window.innerHeight >= 700 && !/Windows|Macintosh|Linux x86/i.test(navigator.userAgent));
    document.body.classList.toggle('modo-tv', !!tv);
    document.body.classList.toggle('modo-mobile', !tv);
  }
  function teclado(e) {
    if (Player.estaAberto()) { if (Player.teclado(e)) return; }
    var k = e.key;
    var dialogoAberto = !$('dialogo').classList.contains('oculta');
    var alvo = document.activeElement, emInput = alvo && (alvo.tagName === 'INPUT' || alvo.tagName === 'SELECT' || alvo.tagName === 'TEXTAREA');
    if ((k === 'Escape' || k === 'Backspace' || k === 'GoBack' || k === 'BrowserBack') && !emInput) {
      e.preventDefault();
      if (dialogoAberto) { fecharDialogo(); return; }
      if (!$('tela-app').classList.contains('oculta')) voltar();
      return;
    }
    if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].indexOf(k) !== -1) {
      if (emInput && (k === 'ArrowLeft' || k === 'ArrowRight')) return;
      var raiz = dialogoAberto ? $('dialogo') : (Player.estaAberto() ? $('tela-player') : (!$('tela-app').classList.contains('oculta') ? $('tela-app') : $('tela-ativacao')));
      if (moverFoco(raiz, k)) e.preventDefault();
      return;
    }
    // HOTFIX 2.1.2: ao chegar no campo Buscar pelo controle remoto,
    // Enter precisa realmente ativar o input/teclado da TV.
    if (k === 'Enter' && alvo && alvo.tagName === 'INPUT' && alvo.classList.contains('busca')) {
      e.preventDefault();
      try { alvo.focus(); alvo.click(); } catch (err) {}
      return;
    }
    if (k === 'Enter' && alvo && alvo.hasAttribute('data-focusable') && alvo.tagName !== 'BUTTON' && alvo.tagName !== 'INPUT') { alvo.click(); e.preventDefault(); }
  }
  function moverFoco(raiz, dir) {
    var atual = document.activeElement, todos = Array.prototype.slice.call(raiz.querySelectorAll('[data-focusable]')).filter(function (el) { var r = el.getBoundingClientRect(); return r.width > 0 && r.height > 0 && !el.disabled; });
    if (!todos.length) return false;
    if (!atual || !raiz.contains(atual) || !atual.hasAttribute('data-focusable')) { todos[0].focus(); return true; }
    var a = atual.getBoundingClientRect(), ax = a.left + a.width / 2, ay = a.top + a.height / 2, melhor = null, melhorPeso = Infinity;
    todos.forEach(function (el) {
      if (el === atual) return;
      var r = el.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top + r.height / 2, dx = x - ax, dy = y - ay, ok, peso;
      if (dir === 'ArrowUp') { ok = dy < -4; peso = -dy + Math.abs(dx) * 2.5; }
      else if (dir === 'ArrowDown') { ok = dy > 4; peso = dy + Math.abs(dx) * 2.5; }
      else if (dir === 'ArrowLeft') { ok = dx < -4; peso = -dx + Math.abs(dy) * 2.5; }
      else { ok = dx > 4; peso = dx + Math.abs(dy) * 2.5; }
      if (ok && peso < melhorPeso) { melhorPeso = peso; melhor = el; }
    });
    if (melhor) { melhor.focus(); melhor.scrollIntoView({ behavior: 'auto', block: (dir === 'ArrowUp' || dir === 'ArrowDown') ? 'center' : 'nearest', inline: 'nearest' }); return true; }
    return false;
  }

  document.addEventListener('DOMContentLoaded', iniciar);
  // menu "Mais" (celular em pé): tudo que não cabe na barra de baixo
  function menuMais() {
    var itens = [['jogos', '\u26BD Jogos'], ['infantil', '\uD83C\uDFAD Infantil'], ['perfil', '\u263A Perfil'], ['listas', '\u21C4 Trocar lista'], ['config', '\u2699 Configurações']];
    dialogo('<h3>Menu</h3><div class="lista-simples">' + itens.map(function (i) { return '<button data-m="' + i[0] + '" data-focusable><b>' + i[1] + '</b></button>'; }).join('') +
      '<button data-m="atualizar" data-focusable><b>\u21BB Atualizar lista</b></button><button data-m="transmitir" data-focusable><b>\u2197 Transmitir</b></button><button data-m="instalar" data-focusable><b>\u2913 Instalar app</b></button><button data-m="sair" data-focusable><b>\u21B7 Sair</b></button></div>' +
      '<div class="dialogo-botoes"><button class="btn" id="dg-nao" data-focusable>Fechar</button></div>', function (cx) {
      cx.querySelectorAll('[data-m]').forEach(function (b) { b.addEventListener('click', function () {
        var m = b.getAttribute('data-m'); fecharDialogo();
        if (m === 'atualizar') { toast('Atualizando lista...'); revalidar(true).then(function () { mostrarTela('carregando'); carregarCatalogo(); }); }
        else if (m === 'transmitir') dialogoTransmitir();
        else if (m === 'instalar') instalar();
        else if (m === 'sair') sair();
        else ir(m);
      }); });
      $('dg-nao').onclick = fecharDialogo;
    });
  }

  // usado pelo botão VOLTAR do Android: só sai do app quando já está na tela inicial
  function podeSair() {
    if (Player.estaAberto()) return false;
    if (!$('dialogo').classList.contains('oculta')) return false;
    if ($('tela-app').classList.contains('oculta')) return true;
    return E.rota === 'inicio' && !E.pilha.length;
  }

  return { toast: toast, ir: ir, voltar: voltar, dialogoTransmitir: dialogoTransmitir, podeSair: podeSair, favoritarDeFora: favoritarDeFora, progressoNativo: progressoNativo };
})();
if ('serviceWorker' in navigator && location.protocol !== 'file:' && !/ TelaVipAPK\//.test(navigator.userAgent)) {
  navigator.serviceWorker.register('sw.js').then(function (reg) { try { reg.update(); } catch (e) {} }).catch(function () {});
  var recarregou = false;
  navigator.serviceWorker.addEventListener('controllerchange', function () { if (recarregou) return; recarregou = true; location.reload(); });
}
