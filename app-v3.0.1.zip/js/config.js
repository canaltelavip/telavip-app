// ==========================================================
//  CONFIGURAÇÃO DO APP  (único arquivo que você precisa mexer)
// ==========================================================
window.TELAVIP_CONFIG = {
  APP_NAME: 'TelaVip Super',
  VERSAO: '3.0.0',

  // Link do painel (Apps Script), o que termina em /exec
  PAINEL_URL: '',

  // Senha interna (a mesma da aba Config, linha senha_app)
  PAINEL_SENHA: '',

  // De quanto em quanto tempo a tela de ativação consulta o painel (segundos)
  INTERVALO_VERIFICACAO: 30,

  // Enquanto estiver liberado, reconfere bloqueio/exclusão/listas nesse intervalo.
  INTERVALO_REVALIDACAO: 30,

  // Palavras que identificam categorias de esportes (seção Jogos)
  PALAVRAS_ESPORTE: ['esporte', 'sport', 'futebol', 'jogo', 'premiere', 'combate', 'ufc', 'nba', 'nfl', 'espn', 'sportv', 'fight', 'luta', 'copa', 'libertadores', 'brasileir'],

  // Palavras que identificam categorias adultas (escondidas até digitar o PIN)
  PALAVRAS_ADULTO: ['adult', 'adulto', 'xxx', '+18', '18+', 'porn', 'sex']
};
