// Guarda tudo no aparelho (localStorage). Nada aqui vai para a internet.
window.Store = (function () {
  var P = 'telavip_';

  function ler(chave, padrao) {
    try {
      var v = localStorage.getItem(P + chave);
      return v === null ? padrao : JSON.parse(v);
    } catch (e) { return padrao; }
  }
  function gravar(chave, valor) {
    try { localStorage.setItem(P + chave, JSON.stringify(valor)); } catch (e) {}
  }
  function apagar(chave) { try { localStorage.removeItem(P + chave); } catch (e) {} }

  // ---------- identidade do aparelho ----------
  function hex2() { return Math.floor(Math.random() * 256).toString(16).toUpperCase().padStart(2, '0'); }
  function aparelho() {
    var d = ler('aparelho', null);
    if (!d || !d.codigo || !d.chave) {
      d = {
        codigo: ['5A', hex2(), hex2(), hex2(), hex2(), hex2()].join(':'),
        chave: String(Math.floor(100000 + Math.random() * 900000)),
        criado: new Date().toISOString()
      };
      gravar('aparelho', d);
    }
    return d;
  }

  // ---------- configurações ----------
  var VERSAO_CONFIG = 2;    // sobe quando um padrão muda e precisa valer para quem já usa o app
  var PADRAO = {
    _v: VERSAO_CONFIG,
    formato: 'auto',        // auto | m3u8 | ts   (automático = MPEG-TS, menos no iPhone)
    motor: 'auto',          // auto | exo | vlc   (só faz diferença no APK)
    qualidade: 'hd',        // sd | hd | fhd | lista  (qualidade ao abrir um canal)
    pularIntro: 45,
    buffer: 'normal',       // normal | alto
    dispositivo: 'auto',    // auto | tv | mobile
    ajusteTela: 'ajustar',  // ajustar | esticar | zoom
    idioma: 'pt',
    pin: '',
    pinAtivo: false,
    catsOcultas: { live: [], vod: [], series: [] },
    listaAtiva: 0
  };
  function config() {
    var salvo = ler('config', {}) || {};
    if (salvo._v !== VERSAO_CONFIG) {
      // atualiza os padrões novos em quem já tinha o app instalado
      salvo = Object.assign({}, salvo, { _v: VERSAO_CONFIG, qualidade: 'hd', formato: 'auto' });
      gravar('config', salvo);
      apagar('fmt_canais'); apagar('fmt_rank');   // esquece os formatos antigos para o padrão novo valer
    }
    return Object.assign({}, PADRAO, salvo);
  }
  function setConfig(parcial) { gravar('config', Object.assign(config(), parcial)); }

  // ---------- favoritos ----------
  function favoritos() { return ler('favoritos', { live: [], vod: [], series: [] }); }
  function ehFavorito(tipo, id) { return favoritos()[tipo].indexOf(String(id)) !== -1; }
  function alternarFavorito(tipo, id) {
    var f = favoritos(); id = String(id);
    var i = f[tipo].indexOf(id);
    if (i === -1) f[tipo].push(id); else f[tipo].splice(i, 1);
    gravar('favoritos', f);
    return i === -1;
  }

  // ---------- histórico / continuar assistindo ----------
  // progresso: { 'vod:123': {pos, dur, quando, nome, capa}, 'ep:456': {...} }
  function progresso() { return ler('progresso', {}); }
  function salvarProgresso(chave, dados) {
    var p = progresso();
    p[chave] = Object.assign(p[chave] || {}, dados, { quando: Date.now() });
    // mantém só os 60 mais recentes
    var chaves = Object.keys(p).sort(function (a, b) { return p[b].quando - p[a].quando; });
    var novo = {};
    chaves.slice(0, 60).forEach(function (k) { novo[k] = p[k]; });
    gravar('progresso', novo);
  }
  function lerProgresso(chave) { return progresso()[chave] || null; }
  function removerProgresso(chave) {
    var p = progresso();
    if (p[chave]) { delete p[chave]; gravar('progresso', p); }
  }
  function limparProgresso(tipoPrefixo) {
    if (!tipoPrefixo) { apagar('progresso'); return; }
    var p = progresso(), novo = {};
    Object.keys(p).forEach(function (k) { if (k.indexOf(tipoPrefixo) !== 0) novo[k] = p[k]; });
    gravar('progresso', novo);
  }
  function episodiosVistos() { return ler('vistos', {}); }
  function marcarVisto(epId) { var v = episodiosVistos(); v[String(epId)] = Date.now(); gravar('vistos', v); }

  // últimos canais assistidos
  function canaisRecentes() { return ler('canais_recentes', []); }
  function registrarCanal(id) {
    var r = canaisRecentes().filter(function (x) { return x !== String(id); });
    r.unshift(String(id)); gravar('canais_recentes', r.slice(0, 20));
  }

  // ---------- formato que funcionou em cada canal ----------
  function formatoCanal(id) { return ler('fmt_canais', {})[String(id)] || null; }
  function setFormatoCanal(id, fmt) { var m = ler('fmt_canais', {}); m[String(id)] = fmt; var ks = Object.keys(m); if (ks.length > 2000) delete m[ks[0]]; gravar('fmt_canais', m); }

  // formato que funcionou por servidor + qualidade (ex: "srv.com|3" -> "ts")
  function formatoRank(chave) { return ler('fmt_rank', {})[chave] || null; }
  function setFormatoRank(chave, fmt) { var m = ler('fmt_rank', {}); m[chave] = fmt; gravar('fmt_rank', m); }

  // ---------- mensagens já mostradas ----------
  function mensagensVistas() { return ler('msgs_vistas', {}); }
  function setMensagensVistas(v) { gravar('msgs_vistas', v); }

  // ---------- liberação do painel (cache) ----------
  function liberacao() { return ler('liberacao', null); }
  function setLiberacao(l) { if (l) gravar('liberacao', l); else apagar('liberacao'); }

  // ---------- cache da lista ----------
  function cacheLista(chave) { return ler('cache_' + chave, null); }
  function setCacheLista(chave, dados) { gravar('cache_' + chave, { quando: Date.now(), dados: dados }); }

  function limparTudo() {
    Object.keys(localStorage).forEach(function (k) { if (k.indexOf(P) === 0 && k !== P + 'aparelho') localStorage.removeItem(k); });
  }

  return {
    aparelho: aparelho, config: config, setConfig: setConfig,
    favoritos: favoritos, ehFavorito: ehFavorito, alternarFavorito: alternarFavorito,
    progresso: progresso, salvarProgresso: salvarProgresso, lerProgresso: lerProgresso, removerProgresso: removerProgresso, limparProgresso: limparProgresso,
    episodiosVistos: episodiosVistos, marcarVisto: marcarVisto,
    canaisRecentes: canaisRecentes, registrarCanal: registrarCanal,
    formatoCanal: formatoCanal, setFormatoCanal: setFormatoCanal, formatoRank: formatoRank, setFormatoRank: setFormatoRank,
    mensagensVistas: mensagensVistas, setMensagensVistas: setMensagensVistas,
    liberacao: liberacao, setLiberacao: setLiberacao,
    cacheLista: cacheLista, setCacheLista: setCacheLista,
    limparTudo: limparTudo
  };
})();
